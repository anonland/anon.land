(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-post-post-module"], {
    /***/
    "39mQ":
    /*!************************************!*\
      !*** ./src/app/interfaces/post.ts ***!
      \************************************/

    /*! exports provided: Post */

    /***/
    function mQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Post", function () {
        return Post;
      });

      var Post = function Post() {
        _classCallCheck(this, Post);
      };
      /***/

    },

    /***/
    "C63a":
    /*!*******************************************!*\
      !*** ./src/app/pages/post/post.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function C63a(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "* {\n  font-family: \"Visby Round CF\";\n}\n\n.margin-left {\n  margin-left: 3%;\n}\n\n.post-img {\n  display: grid;\n  place-content: center;\n}\n\n.post-img img {\n  min-width: 350px;\n  width: 90vh;\n}\n\n.comment-button {\n  display: grid;\n  grid-template-columns: 1fr 1fr 5fr 3fr;\n}\n\n.comment-button ion-button {\n  --background: var(--ion-color-primary);\n}\n\nion-grid {\n  height: 100%;\n}\n\n.timer {\n  align-items: center;\n  color: var(--ion-color-secondary);\n  display: flex;\n  font-size: 1em;\n  font-weight: bold;\n  justify-content: flex-end;\n  padding: 0.5em;\n}\n\n.loading-comments {\n  height: 100%;\n  width: 100%;\n  z-index: 7;\n  background-color: red;\n}\n\n.post-comments {\n  font-weight: 400;\n}\n\n.post-comments ion-label {\n  --background: var(--ion-color-primary-shade);\n  padding: 4%;\n}\n\n.post-comments .show-comment {\n  align-items: center;\n  background-color: var(--ion-toolbar-background-color);\n  cursor: pointer;\n  display: none;\n  flex-direction: row;\n  font-size: 1.1em;\n  font-weight: bold;\n  height: 100%;\n  justify-content: center;\n  position: absolute;\n  width: 100%;\n  z-index: 10;\n}\n\n.post-comments .show-comment .show-comment-title {\n  font-family: \"Visby Round CF\";\n  font-weight: bold;\n  opacity: 60%;\n  transition: 0.4s ease;\n}\n\n.post-comments .show-comment:hover .show-comment-title {\n  opacity: 100%;\n  transition: 0.4s ease;\n}\n\n.post-comments .anon-information {\n  align-items: center;\n  display: flex;\n}\n\n.post-comments .anon-img {\n  height: 60px;\n  max-width: none !important;\n  width: 60px;\n}\n\n.post-comments .post-tags {\n  background-color: var(--ion-color-primary);\n  color: white;\n  margin-right: 2%;\n  padding: 2px;\n  width: 50px;\n}\n\n.post-comments .comment-options-button {\n  align-items: center;\n  cursor: pointer;\n  display: flex;\n  justify-content: center;\n  position: absolute;\n  right: 5%;\n  width: 30px;\n  height: 17px;\n}\n\n.post-comments .post-op {\n  width: 30px;\n  border-radius: 8px;\n}\n\n.post-comments .post-anon {\n  border-radius: 8px;\n  widows: 60px;\n}\n\n.post-comments .post-id {\n  width: 60px;\n  border-radius: 8px;\n}\n\n.post-comments .comment-content {\n  font-weight: 500;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwb3N0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDZCQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0VBQ0EscUJBQUE7QUFDSjs7QUFBSTtFQUNJLGdCQUFBO0VBQ0EsV0FBQTtBQUVSOztBQUVBO0VBQ0ksYUFBQTtFQUNBLHNDQUFBO0FBQ0o7O0FBQUk7RUFDSSxzQ0FBQTtBQUVSOztBQUVBO0VBQ0ksWUFBQTtBQUNKOztBQUVBO0VBQ0ksbUJBQUE7RUFDQSxpQ0FBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUFDSjs7QUFNQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLHFCQUFBO0FBSEo7O0FBTUE7RUFDSSxnQkFBQTtBQUhKOztBQUlJO0VBQ0ksNENBQUE7RUFDQSxXQUFBO0FBRlI7O0FBS0k7RUFDSSxtQkFBQTtFQUNBLHFEQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FBSFI7O0FBS1E7RUFDSSw2QkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0FBSFo7O0FBT1k7RUFDSSxhQUFBO0VBQ0EscUJBQUE7QUFMaEI7O0FBVUk7RUFDSSxtQkFBQTtFQUNBLGFBQUE7QUFSUjs7QUFXSTtFQUNJLFlBQUE7RUFDQSwwQkFBQTtFQUNBLFdBQUE7QUFUUjs7QUFXSTtFQUNJLDBDQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFUUjs7QUFZSTtFQUNJLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBVlI7O0FBYUk7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7QUFYUjs7QUFjSTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtBQVpSOztBQWVJO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0FBYlI7O0FBZ0JJO0VBQ0ksZ0JBQUE7QUFkUiIsImZpbGUiOiJwb3N0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIioge1xuICAgIGZvbnQtZmFtaWx5OiAnVmlzYnkgUm91bmQgQ0YnO1xufVxuXG4ubWFyZ2luLWxlZnQge1xuICAgIG1hcmdpbi1sZWZ0OiAzJTtcbn1cblxuLnBvc3QtaW1nIHtcbiAgICBkaXNwbGF5OiBncmlkO1xuICAgIHBsYWNlLWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBpbWcge1xuICAgICAgICBtaW4td2lkdGg6IDM1MHB4O1xuICAgICAgICB3aWR0aDogOTB2aDtcbiAgICB9XG59XG5cbi5jb21tZW50LWJ1dHRvbiB7XG4gICAgZGlzcGxheTogZ3JpZDtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgNWZyIDNmcjtcbiAgICBpb24tYnV0dG9uIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gICAgfVxufVxuXG5pb24tZ3JpZCB7XG4gICAgaGVpZ2h0OiAxMDAlO1xufVxuXG4udGltZXIge1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZm9udC1zaXplOiAxZW07XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbiAgICBwYWRkaW5nOiAwLjVlbTtcbn1cblxuLmdyZWVuVGV4dCB7XG5cbn1cblxuLmxvYWRpbmctY29tbWVudHMge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICB6LWluZGV4OiA3O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJlZDtcbn1cblxuLnBvc3QtY29tbWVudHMge1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgaW9uLWxhYmVsIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1zaGFkZSk7XG4gICAgICAgIHBhZGRpbmc6IDQlO1xuICAgIH1cblxuICAgIC5zaG93LWNvbW1lbnQge1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tdG9vbGJhci1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICBmb250LXNpemU6IDEuMWVtO1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgei1pbmRleDogMTA7XG5cbiAgICAgICAgLnNob3ctY29tbWVudC10aXRsZSB7XG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1Zpc2J5IFJvdW5kIENGJztcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgb3BhY2l0eTogNjAlO1xuICAgICAgICAgICAgdHJhbnNpdGlvbjogMC40cyBlYXNlO1xuICAgICAgICB9XG5cbiAgICAgICAgJjpob3ZlciB7XG4gICAgICAgICAgICAuc2hvdy1jb21tZW50LXRpdGxlIHtcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAxMDAlO1xuICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IDAuNHMgZWFzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5hbm9uLWluZm9ybWF0aW9uIHtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICB9XG5cbiAgICAuYW5vbi1pbWcge1xuICAgICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICAgIG1heC13aWR0aDogbm9uZSAhaW1wb3J0YW50O1xuICAgICAgICB3aWR0aDogNjBweDtcbiAgICB9XG4gICAgLnBvc3QtdGFncyB7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDIlO1xuICAgICAgICBwYWRkaW5nOiAycHg7XG4gICAgICAgIHdpZHRoOiA1MHB4O1xuICAgIH1cblxuICAgIC5jb21tZW50LW9wdGlvbnMtYnV0dG9uIHtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICByaWdodDogNSU7XG4gICAgICAgIHdpZHRoOiAzMHB4O1xuICAgICAgICBoZWlnaHQ6IDE3cHg7XG4gICAgfVxuXG4gICAgLnBvc3Qtb3Age1xuICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4OyAgIFxuICAgIH1cblxuICAgIC5wb3N0LWFub24ge1xuICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgICAgIHdpZG93czogNjBweDtcbiAgICB9XG5cbiAgICAucG9zdC1pZCB7XG4gICAgICAgIHdpZHRoOiA2MHB4O1xuICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgfVxuXG4gICAgLmNvbW1lbnQtY29udGVudCB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgfVxuXG59XG4iXX0= */";
      /***/
    },

    /***/
    "CX4s":
    /*!***************************************************!*\
      !*** ./src/app/pages/post/post-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: PostPageRoutingModule */

    /***/
    function CX4s(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PostPageRoutingModule", function () {
        return PostPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _post_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./post.page */
      "cxgS");

      var routes = [{
        path: '',
        component: _post_page__WEBPACK_IMPORTED_MODULE_3__["PostPage"]
      }];

      var PostPageRoutingModule = function PostPageRoutingModule() {
        _classCallCheck(this, PostPageRoutingModule);
      };

      PostPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PostPageRoutingModule);
      /***/
    },

    /***/
    "ElmB":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/post/post.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function ElmB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"end\">\n      <ion-back-button text=\"Atrás\" defaultHref=\"/\" (click)=\"navigateToMain($evt)\"></ion-back-button>\n    </ion-buttons>\n    <ion-title class=\"margin-left\">{{post.title}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row class=\"height-100\">\n      <ion-col sizeLg=\"7\" sizeMd=\"7\" sizeSm=\"12\" sizeXs=\"12\">\n        <div class=\"post-img\">\n          <img [src]='post.imgPath'>\n        </div>\n        <div *ngIf=\"this.authServ.user != undefined\">\n          <ion-button (click)=\"deletePost()\">\n            <ion-icon name=\"trash-outline\"></ion-icon>Borrar\n          </ion-button>\n          <ion-button (click)=\"selMove.open()\">\n            <ion-icon name=\"arrow-redo\"></ion-icon>Mover\n          </ion-button>\n          <ion-button (click)=\"banUser()\">\n            <ion-icon name=\"skull\"></ion-icon>Banear\n          </ion-button>\n          <ion-select placeholder=\"General\" okText=\"Elegir\" cancelText=\"Cancelar\" (ionChange)=\"movePost()\" #selMove>\n            <ion-select-option value=\"off\">General</ion-select-option>\n            <ion-select-option value=\"prg\">Preguntas</ion-select-option>\n            <ion-select-option value=\"mus\">Música</ion-select-option>\n            <ion-select-option value=\"cin\">Cine</ion-select-option>\n            <ion-select-option value=\"sci\">Ciencia</ion-select-option>\n            <ion-select-option value=\"his\">Historia</ion-select-option>\n            <ion-select-option value=\"pol\">Política</ion-select-option>\n            <ion-select-option value=\"art\">Arte</ion-select-option>\n            <ion-select-option value=\"nor\">Normie</ion-select-option>\n            <ion-select-option value=\"uff\">Random</ion-select-option>\n            <ion-select-option value=\"anm\">Anime</ion-select-option>\n          </ion-select>\n        </div>\n        <div *ngIf=\"this.authServ.user == undefined\">\n          <ion-button class=\"margin-left\" (click)=\"report()\">\n            <ion-icon slot=\"start\" name=\"flag\"></ion-icon>Reportar\n          </ion-button>\n        </div>\n        <h2 class=\"margin-left\">{{post.body}}</h2>\n      </ion-col>\n      <ion-col sizeLg=\"5\" sizeMd=\"5\" sizeSm=\"12\" sizeXs=\"12\" class=\"comments-container\">\n        <ion-row>\n          <ion-col size=\"7\">\n            <ion-textarea placeholder=\"Hacer un comentario\" maxlength=\"250\" autofocus=\"true\" rows=\"7\" #txtComment>\n            </ion-textarea>\n          </ion-col>\n          <ion-col size=\"5\">\n            <img [src]=\"imgPreview\" width=\"200px\" height=\"200px\" alt=\"\">\n          </ion-col>\n        </ion-row>\n        <div class=\"comment-button\">\n          <input id=\"upload-img\" type=\"file\" name=\"post-img-upload\" accept=\"image/*\" (change)=\"onSelectFile($event)\"\n            hidden />\n          <ion-button style=\"--padding-end: 0px; --padding-start: 0px; --padding-top: 0px; --padding-bottom: 0px;\">\n            <label for=\"upload-img\" id=\"file-drag\">\n              <ion-icon name=\"image\" style=\"padding: 10px 15px;cursor: pointer;\"></ion-icon>\n            </label>\n          </ion-button>\n          <ion-button style=\"--padding-end: 0px; --padding-start: 0px; --padding-top: 0px; --padding-bottom: 0px;\">\n            <ion-icon name=\"link\" style=\"padding: 10px 15px;cursor: pointer;\"></ion-icon>\n          </ion-button>\n          <div class=\"timer\">\n            {{ timer }}\n          </div>\n          <ion-button disabled=\"{{ commentBtnDisabled }}\" (click)=\"comment()\">\n            <ion-icon slot=\"end\" name=\"send\"></ion-icon>\n            Comentar\n          </ion-button>\n        </div>\n        <ion-list>\n          <ion-item>\n            <h4>Comentarios:</h4>\n          </ion-item>\n          <ion-item class=\"post-comments\" *ngFor=\"let comment of comments\">\n            <div class=\"show-comment\" id=\"comment_{{ comment.id }}\" (click)=\"showComment(comment.id)\">\n              <ion-icon class=\"show-comment-title\" slot=\"start\" ios=\"eye-off-outline\" md=\"eye-off-sharp\"></ion-icon>\n              <ion-label class=\"show-comment-title\">Click para mostrar</ion-label>\n            </div>\n            <ion-avatar slot=\"start\">\n              <img class=\"anon-img\" [src]=\"'../../../assets/anon/anon-'+ comment.anonType +'.svg'\">\n            </ion-avatar>\n            <ion-label>\n              <div class=\"anon-information\">\n                <ion-badge class=\"post-tags post-op\" color=\"medium\" *ngIf=\"comment.userId == post.opid\">OP</ion-badge>\n                <ion-badge class=\"post-tags post-anon\" color=\"medium\" *ngIf=\"comment.userId != post.opid\">ANON\n                </ion-badge>\n                <ion-badge class=\"post-tags post-id\" color=\"medium\">{{comment.userId}}</ion-badge>\n                <ion-label color=\"medium\" class=\"comment-options-button\"\n                  style=\"width: 120px;bottom: 0px; right: 0px; font-size: 85%\">{{comment.createdAt | timestampToDate}}\n                </ion-label>\n                <ion-badge color=\"medium\" class=\"comment-options-button\" (click)=\"showOptions($event, comment.id, comment.userId)\">\n                  <ion-icon name=\"chevron-down\"></ion-icon>\n                </ion-badge>\n              </div>\n              <div class=\"comment-content\" [innerHtml]=\"comment.body\">\n              </div>\n              <img *ngIf=\"comment.imgPath\" [src]=\"comment.imgPath\" width=\"150px\" height=\"150px\">\n            </ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>";
      /***/
    },

    /***/
    "FoK2":
    /*!*************************************************************************!*\
      !*** ./src/app/components/comment-options/comment-options.component.ts ***!
      \*************************************************************************/

    /*! exports provided: CommentOptionsComponent */

    /***/
    function FoK2(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CommentOptionsComponent", function () {
        return CommentOptionsComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_comment_options_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./comment-options.component.html */
      "b2X+");
      /* harmony import */


      var _comment_options_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./comment-options.component.scss */
      "ysdt");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");
      /* harmony import */


      var src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/helpers/functions */
      "3crM");
      /* harmony import */


      var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! src/app/services/auth.service */
      "lGQG");

      var CommentOptionsComponent = /*#__PURE__*/function () {
        function CommentOptionsComponent(http, toastCtrl, popoverCtrl, storage, authServ) {
          _classCallCheck(this, CommentOptionsComponent);

          this.http = http;
          this.toastCtrl = toastCtrl;
          this.popoverCtrl = popoverCtrl;
          this.storage = storage;
          this.authServ = authServ;
        }

        _createClass(CommentOptionsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {} // Report a comment sending the commentId.

        }, {
          key: "report",
          value: function report() {
            var _this = this;

            this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_7__["createUrl"])('reportComment'), {
              commentID: this.commentId
            }, {
              responseType: 'text'
            }).subscribe(function () {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var toast;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return this.toastCtrl.create({
                          header: 'El comentario fue reportado.',
                          position: 'top',
                          duration: 4000
                        });

                      case 2:
                        toast = _context.sent;
                        _context.next = 5;
                        return toast.present();

                      case 5:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            });
            this.popoverCtrl.dismiss();
          } // Hide a comment per commentId and save as index in IonStorage,

        }, {
          key: "hide",
          value: function hide() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var comment, commentIcon, id;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      comment = document.querySelector("#comment_".concat(this.commentId));
                      commentIcon = document.querySelector("#comment_".concat(this.commentId, " + ion-avatar"));
                      comment.style.display = 'flex';
                      commentIcon.style.display = 'none'; // Dismiss options.

                      this.popoverCtrl.dismiss(); // Save the comment.

                      _context2.next = 7;
                      return this.storage.get('hiddenCommentId');

                    case 7:
                      id = _context2.sent;

                      if (!id) {
                        _context2.next = 13;
                        break;
                      }

                      id.push(this.commentId);
                      return _context2.abrupt("return", this.storage.set('hiddenCommentId', id));

                    case 13:
                      return _context2.abrupt("return", this.storage.set('hiddenCommentId', [this.commentId]));

                    case 14:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "delete",
          value: function _delete() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var _this2 = this;

              var adminToken;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.authServ.getToken();

                    case 2:
                      adminToken = _context4.sent;
                      this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_7__["createUrl"])('delete-comment'), {
                        commentID: this.commentId,
                        token: adminToken
                      }, {
                        responseType: 'text'
                      }).subscribe(function () {
                        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
                          var toast;
                          return regeneratorRuntime.wrap(function _callee3$(_context3) {
                            while (1) {
                              switch (_context3.prev = _context3.next) {
                                case 0:
                                  _context3.next = 2;
                                  return this.toastCtrl.create({
                                    header: 'El comentario fue borrado.',
                                    position: 'top',
                                    duration: 4000
                                  });

                                case 2:
                                  toast = _context3.sent;
                                  _context3.next = 5;
                                  return toast.present();

                                case 5:
                                case "end":
                                  return _context3.stop();
                              }
                            }
                          }, _callee3, this);
                        }));
                      });
                      this.popoverCtrl.dismiss();

                    case 5:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "ban",
          value: function ban() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var _this3 = this;

              var adminToken;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      _context6.next = 2;
                      return this.authServ.getToken();

                    case 2:
                      adminToken = _context6.sent;
                      this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_7__["createUrl"])('ban'), {
                        userID: this.userID,
                        token: adminToken
                      }, {
                        responseType: 'text'
                      }).subscribe(function () {
                        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                          var toast;
                          return regeneratorRuntime.wrap(function _callee5$(_context5) {
                            while (1) {
                              switch (_context5.prev = _context5.next) {
                                case 0:
                                  _context5.next = 2;
                                  return this.toastCtrl.create({
                                    header: 'El usuario fue baneado.',
                                    position: 'top',
                                    duration: 4000
                                  });

                                case 2:
                                  toast = _context5.sent;
                                  _context5.next = 5;
                                  return toast.present();

                                case 5:
                                case "end":
                                  return _context5.stop();
                              }
                            }
                          }, _callee5, this);
                        }));
                      });
                      this.popoverCtrl.dismiss();

                    case 5:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }]);

        return CommentOptionsComponent;
      }();

      CommentOptionsComponent.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]
        }, {
          type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"]
        }];
      };

      CommentOptionsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-comment-options',
        template: _raw_loader_comment_options_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_comment_options_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CommentOptionsComponent);
      /***/
    },

    /***/
    "IThU":
    /*!*************************************************!*\
      !*** ./src/app/pipes/timestamp-to-date.pipe.ts ***!
      \*************************************************/

    /*! exports provided: TimestampToDatePipe */

    /***/
    function IThU(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TimestampToDatePipe", function () {
        return TimestampToDatePipe;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var TimestampToDatePipe = /*#__PURE__*/function () {
        function TimestampToDatePipe() {
          _classCallCheck(this, TimestampToDatePipe);
        }

        _createClass(TimestampToDatePipe, [{
          key: "transform",
          value: function transform(value) {
            return new Date(value.toMillis()).toLocaleString([], {
              day: '2-digit',
              month: '2-digit',
              year: '2-digit',
              hour: '2-digit',
              minute: '2-digit'
            });
          }
        }]);

        return TimestampToDatePipe;
      }();

      TimestampToDatePipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'timestampToDate'
      })], TimestampToDatePipe);
      /***/
    },

    /***/
    "b2X+":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/comment-options/comment-options.component.html ***!
      \*****************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function b2X(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-item (click)=\"report()\">\n  <ion-icon slot=\"start\" name=\"flag\"></ion-icon>\n  <ion-label>Denunciar</ion-label>\n</ion-item>\n<ion-item (click)=\"hide()\">\n  <ion-icon slot=\"start\" name=\"eye-off\"></ion-icon>\n  <ion-label>Ocultar</ion-label>\n</ion-item>\n<ion-item [hidden]=\"this.authServ.user == undefined\" (click)=\"delete()\">\n  <ion-icon slot=\"start\" name=\"trash\"></ion-icon>\n  <ion-label>Borrar</ion-label>\n</ion-item>\n<ion-item [hidden]=\"this.authServ.user == undefined\" (click)=\"ban()\">\n  <ion-icon slot=\"start\" name=\"skull\"></ion-icon>\n  <ion-label>Banear usuario</ion-label>\n</ion-item>";
      /***/
    },

    /***/
    "cxgS":
    /*!*****************************************!*\
      !*** ./src/app/pages/post/post.page.ts ***!
      \*****************************************/

    /*! exports provided: PostPage */

    /***/
    function cxgS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PostPage", function () {
        return PostPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_post_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./post.page.html */
      "ElmB");
      /* harmony import */


      var _post_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./post.page.scss */
      "C63a");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var src_app_components_comment_options_comment_options_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! src/app/components/comment-options/comment-options.component */
      "FoK2");
      /* harmony import */


      var src_app_interfaces_post__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! src/app/interfaces/post */
      "39mQ");
      /* harmony import */


      var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! src/app/services/auth.service */
      "lGQG");
      /* harmony import */


      var src_app_services_post_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! src/app/services/post.service */
      "ENZJ");
      /* harmony import */


      var src_app_services_session_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! src/app/services/session.service */
      "IfdK");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");
      /* harmony import */


      var src_app_services_comment_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! src/app/services/comment.service */
      "mxDV");
      /* harmony import */


      var src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! src/app/helpers/functions */
      "3crM");

      var PostPage = /*#__PURE__*/function () {
        function PostPage(toastCtrl, activatedRoute, title, http, postServ, authServ, alertCtrl, sessionServ, popoverCtrl, router, storage, commentServ) {
          _classCallCheck(this, PostPage);

          this.toastCtrl = toastCtrl;
          this.activatedRoute = activatedRoute;
          this.title = title;
          this.http = http;
          this.postServ = postServ;
          this.authServ = authServ;
          this.alertCtrl = alertCtrl;
          this.sessionServ = sessionServ;
          this.popoverCtrl = popoverCtrl;
          this.router = router;
          this.storage = storage;
          this.commentServ = commentServ;
          this.post = new src_app_interfaces_post__WEBPACK_IMPORTED_MODULE_9__["Post"]();
          this.comments = new Array();
          this.commentBtnDisabled = false; // Button is enable.

          this.imgPreview = '../../../assets/anon/anon-1.svg';
          this.newComments = 0;
        }

        _createClass(PostPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              var postDoc;
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      this.postId = this.activatedRoute.snapshot.paramMap.get('postId');
                      _context7.next = 3;
                      return this.postServ.getPostById(this.postId).toPromise();

                    case 3:
                      postDoc = _context7.sent;

                      if (!(!postDoc || !postDoc.exists)) {
                        _context7.next = 7;
                        break;
                      }

                      this.router.navigate(['/']);
                      return _context7.abrupt("return");

                    case 7:
                      this.post = postDoc.data();
                      this.title.setTitle(this.post.title + ' | Anon Land');
                      this.getComments();
                      this.setSocketsHandler();

                    case 11:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }, {
          key: "setSocketsHandler",
          value: function setSocketsHandler() {
            var _this4 = this;

            this.commentServ.setSocketsHandler(this.postId, function () {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this4, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
                var _this5 = this;

                var header, toast, reloadComments;
                return regeneratorRuntime.wrap(function _callee8$(_context8) {
                  while (1) {
                    switch (_context8.prev = _context8.next) {
                      case 0:
                        this.newComments++;
                        header = this.newComments == 1 ? "Hay 1 nuevo comentario" : "Hay ".concat(this.newComments, " nuevos comentarios");

                        if (!(this.newCommentsToast == undefined)) {
                          _context8.next = 13;
                          break;
                        }

                        _context8.next = 5;
                        return this.toastCtrl.create({
                          header: header,
                          duration: 600000,
                          position: 'top',
                          color: 'success'
                        });

                      case 5:
                        toast = _context8.sent;
                        _context8.next = 8;
                        return toast.present();

                      case 8:
                        reloadComments = function reloadComments() {
                          toast.dismiss();
                          _this5.newComments = 0;
                          _this5.newCommentsToast = undefined;

                          _this5.getComments();
                        };

                        toast.onclick = reloadComments;
                        this.newCommentsToast = toast;
                        _context8.next = 14;
                        break;

                      case 13:
                        this.newCommentsToast.header = header;

                      case 14:
                      case "end":
                        return _context8.stop();
                    }
                  }
                }, _callee8, this);
              }));
            });
          }
        }, {
          key: "commentTimer",
          value: function commentTimer() {
            var _this6 = this;

            this.commentBtnDisabled = true;
            setTimeout(function () {
              _this6.commentBtnDisabled = false;
            }, 5000); // Time to wait for comment.

            var timeLeft = 5;
            var commentTime = setInterval(function () {
              timeLeft--;
              _this6.timer = "Esperar ".concat(timeLeft, "s");

              if (timeLeft === 0) {
                clearInterval(commentTime);
                _this6.timer = ''; // Disappear timer.
              }
            }, 1000); // Refresh each 1s.
          }
        }, {
          key: "comment",
          value: function comment() {
            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var _this7 = this;

              var _toast, body, _toast2, greenText, buttonAlert, formData;

              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      if (!(((_a = this.txtComment.value) === null || _a === void 0 ? void 0 : _a.length) == 0)) {
                        _context10.next = 7;
                        break;
                      }

                      _context10.next = 3;
                      return this.toastCtrl.create({
                        header: 'El comentario está vacio',
                        duration: 3000,
                        position: 'top',
                        color: 'warning'
                      });

                    case 3:
                      _toast = _context10.sent;
                      _context10.next = 6;
                      return _toast.present();

                    case 6:
                      return _context10.abrupt("return");

                    case 7:
                      // Replace escaped characters.
                      body = this.txtComment.value.replace(/(?:\r\n|\r|\n)/g, '<br>');

                      if (!((body.match(/<br>/g) || []).length > 4 || body.length > 250)) {
                        _context10.next = 15;
                        break;
                      }

                      _context10.next = 11;
                      return this.toastCtrl.create({
                        header: 'El comentario es muy largo',
                        duration: 3000,
                        position: 'top',
                        color: 'warning'
                      });

                    case 11:
                      _toast2 = _context10.sent;
                      _context10.next = 14;
                      return _toast2.present();

                    case 14:
                      return _context10.abrupt("return");

                    case 15:
                      // Make green text.
                      greenText = '<div style="color: #2dd36f; font-weight: bold;">$1</div>';
                      body = body.replace(/((^|\s|\t)[>].*<br>)/g, greenText); // Alert message.

                      // Manage comment status.
                      buttonAlert = 'Mensaje publicado correctamente.';
                      this.txtComment.value = "";
                      this.commentTimer();
                      this.commentServ.removeSocketsHandler(this.postId);
                      formData = new FormData();
                      formData.append('body', body);
                      formData.append('post-img-upload', this.imgComment);
                      formData.append('postId', this.postId);
                      _context10.t0 = formData;
                      _context10.next = 28;
                      return this.sessionServ.getSession();

                    case 28:
                      _context10.t1 = _context10.sent;

                      _context10.t0.append.call(_context10.t0, 'userId', _context10.t1);

                      this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_15__["createUrl"])('comment'), formData, {
                        responseType: 'text'
                      }).subscribe(function (_) {
                        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this7, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
                          var toast;
                          return regeneratorRuntime.wrap(function _callee9$(_context9) {
                            while (1) {
                              switch (_context9.prev = _context9.next) {
                                case 0:
                                  this.getComments();
                                  this.setSocketsHandler();
                                  _context9.next = 4;
                                  return this.toastCtrl.create({
                                    message: buttonAlert,
                                    position: 'top',
                                    duration: 3000
                                  });

                                case 4:
                                  toast = _context9.sent;
                                  _context9.next = 7;
                                  return toast.present();

                                case 7:
                                case "end":
                                  return _context9.stop();
                              }
                            }
                          }, _callee9, this);
                        }));
                      });

                    case 31:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this);
            }));
          }
        }, {
          key: "getComments",
          value: function getComments() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              var _this8 = this;

              var comments;
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      _context11.next = 2;
                      return this.postServ.getComments(this.postId);

                    case 2:
                      comments = _context11.sent;
                      this.comments = comments.docs.map(function (comment) {
                        var commentObj = comment.data();
                        commentObj.id = comment.id; // Display placard for each hide comment.

                        _this8.storage.forEach(function (key, value) {
                          if (value === 'hiddenCommentId') {
                            key.forEach(function (id) {
                              return _this8.toggleHide(id);
                            });
                          }
                        });

                        return commentObj;
                      });

                    case 4:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this);
            }));
          }
        }, {
          key: "showOptions",
          value: function showOptions($event, commentId, userID) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
              var popover;
              return regeneratorRuntime.wrap(function _callee12$(_context12) {
                while (1) {
                  switch (_context12.prev = _context12.next) {
                    case 0:
                      $event.stopPropagation();
                      _context12.next = 3;
                      return this.popoverCtrl.create({
                        component: src_app_components_comment_options_comment_options_component__WEBPACK_IMPORTED_MODULE_8__["CommentOptionsComponent"],
                        event: $event,
                        componentProps: {
                          commentId: commentId,
                          userID: userID
                        }
                      });

                    case 3:
                      popover = _context12.sent;
                      _context12.next = 6;
                      return popover.present();

                    case 6:
                    case "end":
                      return _context12.stop();
                  }
                }
              }, _callee12, this);
            }));
          } // Disappear placard on the comment and show then.

        }, {
          key: "showComment",
          value: function showComment(commentId) {
            var _this9 = this;

            var comment = document.querySelector("#comment_".concat(commentId));
            var commentIcon = document.querySelector("#comment_".concat(commentId, " + ion-avatar"));
            comment.style.display = 'none';
            commentIcon.style.display = 'block'; // Delete the comment id as value from 'hiddenCommentId'.

            this.storage.get('hiddenCommentId').then(function (id) {
              if (!id || id.length === 0) {
                return null;
              } // Do nothing if is null.


              var toKeep = [];

              var _iterator = _createForOfIteratorHelper(id),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var i = _step.value;

                  if (i !== commentId) {
                    toKeep.push(i);
                  }
                } // Finally return the new hidden comments list.

              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }

              _this9.storage.set('hiddenCommentId', toKeep);
            });
          } // Display placard for show the comment.
          // Function is call in getComments().

        }, {
          key: "toggleHide",
          value: function toggleHide(commentId) {
            var comment = document.querySelector("#comment_".concat(commentId));
            var commentIcon = document.querySelector("#comment_".concat(commentId, " + ion-avatar"));
            comment.style.display = 'flex';
            commentIcon.style.display = 'none';
          }
        }, {
          key: "deletePost",
          value: function deletePost() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
              var _this10 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee14$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      _context14.next = 2;
                      return this.alertCtrl.create({
                        header: 'Borrar post',
                        message: '¿Estas seguro de borrar este post?',
                        buttons: [{
                          text: 'Cancelar',
                          role: 'cancel'
                        }, {
                          text: 'Aceptar',
                          handler: function handler() {
                            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this10, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
                              var toast;
                              return regeneratorRuntime.wrap(function _callee13$(_context13) {
                                while (1) {
                                  switch (_context13.prev = _context13.next) {
                                    case 0:
                                      _context13.next = 2;
                                      return this.postServ.deletePost(this.postId);

                                    case 2:
                                      _context13.next = 4;
                                      return this.toastCtrl.create({
                                        header: 'Post borrado correctamente'
                                      });

                                    case 4:
                                      toast = _context13.sent;
                                      _context13.next = 7;
                                      return toast.present();

                                    case 7:
                                    case "end":
                                      return _context13.stop();
                                  }
                                }
                              }, _callee13, this);
                            }));
                          }
                        }]
                      });

                    case 2:
                      alert = _context14.sent;
                      alert.present();

                    case 4:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee14, this);
            }));
          }
        }, {
          key: "deleteComment",
          value: function deleteComment() {}
        }, {
          key: "movePost",
          value: function movePost() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
              var toast;
              return regeneratorRuntime.wrap(function _callee15$(_context15) {
                while (1) {
                  switch (_context15.prev = _context15.next) {
                    case 0:
                      if (!(this.selMove.value == null)) {
                        _context15.next = 2;
                        break;
                      }

                      return _context15.abrupt("return");

                    case 2:
                      _context15.next = 4;
                      return this.postServ.movePost(this.postId, this.selMove.value);

                    case 4:
                      _context15.next = 6;
                      return this.toastCtrl.create({
                        header: 'Post movido correctamente'
                      });

                    case 6:
                      toast = _context15.sent;
                      _context15.next = 9;
                      return toast.present();

                    case 9:
                    case "end":
                      return _context15.stop();
                  }
                }
              }, _callee15, this);
            }));
          }
        }, {
          key: "banUser",
          value: function banUser() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
              var toast;
              return regeneratorRuntime.wrap(function _callee16$(_context16) {
                while (1) {
                  switch (_context16.prev = _context16.next) {
                    case 0:
                      _context16.next = 2;
                      return this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_15__["createUrl"])('ban'), {
                        opIP: this.post.opIP
                      }).toPromise();

                    case 2:
                      _context16.next = 4;
                      return this.toastCtrl.create({
                        header: 'Usuario baneado correctamente'
                      });

                    case 4:
                      toast = _context16.sent;
                      _context16.next = 7;
                      return toast.present();

                    case 7:
                    case "end":
                      return _context16.stop();
                  }
                }
              }, _callee16, this);
            }));
          }
        }, {
          key: "report",
          value: function report() {
            var _this11 = this;

            this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_15__["createUrl"])('report'), {
              postID: this.post.id
            }, {
              responseType: 'text'
            }).subscribe(function () {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this11, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
                var toast;
                return regeneratorRuntime.wrap(function _callee17$(_context17) {
                  while (1) {
                    switch (_context17.prev = _context17.next) {
                      case 0:
                        _context17.next = 2;
                        return this.toastCtrl.create({
                          header: 'Post reportado correctamente',
                          position: 'top'
                        });

                      case 2:
                        toast = _context17.sent;
                        _context17.next = 5;
                        return toast.present();

                      case 5:
                      case "end":
                        return _context17.stop();
                    }
                  }
                }, _callee17, this);
              }));
            });
          }
        }, {
          key: "onSelectFile",
          value: function onSelectFile(preview) {
            var _this12 = this;

            if (preview.target.files && preview.target.files[0]) {
              var reader = new FileReader();
              reader.readAsDataURL(preview.target.files[0]); // read file as data url

              reader.onload = function (event) {
                _this12.imgComment = preview.target.files[0];
                _this12.imgPreview = event.target.result.toString();
              };
            }
          }
        }, {
          key: "navigateToMain",
          value: function navigateToMain() {
            this.commentServ.removeSocketsHandler(this.postId);
            this.router.navigate['/'];
          }
        }]);

        return PostPage;
      }();

      PostPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"]
        }, {
          type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["Title"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }, {
          type: src_app_services_post_service__WEBPACK_IMPORTED_MODULE_11__["PostService"]
        }, {
          type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_10__["AuthService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"]
        }, {
          type: src_app_services_session_service__WEBPACK_IMPORTED_MODULE_12__["SessionService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["PopoverController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_13__["Storage"]
        }, {
          type: src_app_services_comment_service__WEBPACK_IMPORTED_MODULE_14__["CommentService"]
        }];
      };

      PostPage.propDecorators = {
        txtComment: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"],
          args: ['txtComment']
        }],
        selMove: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"],
          args: ['selMove']
        }]
      };
      PostPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-post',
        template: _raw_loader_post_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_post_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PostPage);
      /***/
    },

    /***/
    "gDdP":
    /*!*******************************************!*\
      !*** ./src/app/pages/post/post.module.ts ***!
      \*******************************************/

    /*! exports provided: PostPageModule */

    /***/
    function gDdP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PostPageModule", function () {
        return PostPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _post_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./post-routing.module */
      "CX4s");
      /* harmony import */


      var _post_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./post.page */
      "cxgS");
      /* harmony import */


      var src_app_pipes_timestamp_to_date_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/pipes/timestamp-to-date.pipe */
      "IThU");

      var PostPageModule = function PostPageModule() {
        _classCallCheck(this, PostPageModule);
      };

      PostPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _post_routing_module__WEBPACK_IMPORTED_MODULE_5__["PostPageRoutingModule"]],
        declarations: [_post_page__WEBPACK_IMPORTED_MODULE_6__["PostPage"], src_app_pipes_timestamp_to_date_pipe__WEBPACK_IMPORTED_MODULE_7__["TimestampToDatePipe"]]
      })], PostPageModule);
      /***/
    },

    /***/
    "mxDV":
    /*!*********************************************!*\
      !*** ./src/app/services/comment.service.ts ***!
      \*********************************************/

    /*! exports provided: CommentService */

    /***/
    function mxDV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CommentService", function () {
        return CommentService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _socket_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./socket.service */
      "5U9e");

      var CommentService = /*#__PURE__*/function () {
        function CommentService(socket) {
          _classCallCheck(this, CommentService);

          this.socket = socket;
        }

        _createClass(CommentService, [{
          key: "setSocketsHandler",
          value: function setSocketsHandler(postId, handler) {
            this.socket.io.on("".concat(postId, "/newComment"), handler);
          }
        }, {
          key: "removeSocketsHandler",
          value: function removeSocketsHandler(postId) {
            this.socket.io.off("".concat(postId, "/newComment"));
          }
        }]);

        return CommentService;
      }();

      CommentService.ctorParameters = function () {
        return [{
          type: _socket_service__WEBPACK_IMPORTED_MODULE_2__["SocketService"]
        }];
      };

      CommentService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], CommentService);
      /***/
    },

    /***/
    "ysdt":
    /*!***************************************************************************!*\
      !*** ./src/app/components/comment-options/comment-options.component.scss ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function ysdt(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-item {\n  cursor: pointer;\n}\nion-item ion-icon {\n  color: var(--ion-color-medium);\n  margin-right: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb21tZW50LW9wdGlvbnMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0FBQ0o7QUFBUTtFQUNJLDhCQUFBO0VBQ0Esa0JBQUE7QUFFWiIsImZpbGUiOiJjb21tZW50LW9wdGlvbnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XG4gICAgICAgIH1cbn1cbiJdfQ== */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-post-post-module-es5.js.map