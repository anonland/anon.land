(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! D:\voxed4\site\src\main.ts */
      "zUnb");
      /***/
    },

    /***/
    "AytR":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function AytR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false,
        firebaseConfig: {
          apiKey: "AIzaSyCH2IqWNCciLwR-ppVlgAkOflO8ijs0NcM",
          authDomain: "voxednet2.firebaseapp.com",
          databaseURL: "https://voxednet2.firebaseio.com",
          projectId: "voxednet2",
          storageBucket: "voxednet2.appspot.com",
          messagingSenderId: "22189364424",
          appId: "1:22189364424:web:ab7ff26753eb120cba41fd",
          measurementId: "G-SPYXQY64ZN"
        }
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "Fadn":
    /*!****************************************************************************!*\
      !*** ./src/app/pages/color-scheme-modal/color-scheme-modal.component.scss ***!
      \****************************************************************************/

    /*! exports provided: default */

    /***/
    function Fadn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".modal-title {\n  align-items: center;\n  color: var(--ion-text-color);\n  display: flex;\n  font-size: 1.2em;\n  font-weight: bold;\n  justify-content: space-between;\n  padding: 5%;\n}\n\nion-content,\nion-label,\nion-list,\nion-list-header,\nion-radio-group {\n  --background: none !important;\n  background: none !important;\n}\n\n.container {\n  color: var(--ion-text-color);\n  display: grid;\n  height: 100%;\n  grid-template-columns: 2fr 2fr;\n}\n\n.select-escena {\n  display: grid;\n  grid-template-columns: 1fr 2fr;\n  margin: 5% 0 5% 0;\n}\n\n.select-escena ion-label {\n  align-self: center;\n  font-size: 1.2em;\n  font-weight: bold;\n  text-align: center;\n}\n\n.escena-toggle {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\n.escena-toggle ion-icon {\n  height: 30px;\n  width: 30px;\n}\n\n.escena-toggle ion-toggle {\n  width: 60px;\n  height: 30px;\n}\n\n.select-color {\n  display: grid;\n  grid-template-columns: 1fr 2fr;\n}\n\n.select-color ion-label {\n  align-items: center;\n  display: flex;\n  font-size: 1.2em;\n  font-weight: bold;\n  justify-content: center;\n}\n\n.color-selected {\n  --color: white;\n  font-size: 0.8em;\n  font-weight: 400;\n  border-radius: 16px;\n  display: flex;\n  align-items: center;\n  height: 40px;\n  margin: 4% 0 4% 0;\n  transition: 0.4s ease;\n  widows: 100px;\n}\n\n.color-selected ion-radio {\n  --color: var(--ion-color-light);\n}\n\n.color-selected:nth-child(1) {\n  --background: #8414FF;\n}\n\n.color-selected:nth-child(2) {\n  --background: #FF3E14;\n}\n\n.color-selected:nth-child(3) {\n  --background: #0A68B2;\n}\n\n.color-selected:nth-child(4) {\n  --background: #4fff75;\n  --color: var(--ion-color-dark);\n}\n\n.color-selected:hover {\n  filter: brightness(80%);\n  transition: 0.4s ease;\n}\n\n.img-preview-desktop, .img-preview-mobile {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.img-preview-mobile {\n  display: none;\n}\n\ng rect:nth-child(1) {\n  fill: var(--ion-background-color);\n}\n\ng rect {\n  fill: var(--ion-color-primary);\n}\n\n@supports not ((-webkit-backdrop-filter: none) or (backdrop-filter: none)) {\n  .container,\n.modal-title {\n    color: white;\n  }\n}\n\n@media only screen and (max-width: 767px) {\n  .modal-title {\n    font-size: 1em;\n    position: absolute;\n    top: 0;\n    width: 100%;\n  }\n\n  .container {\n    margin-top: 10%;\n    grid-template-columns: none;\n    grid-template-rows: 2fr 2fr;\n  }\n\n  .options {\n    grid-row: 2;\n  }\n\n  .select-escena {\n    grid-template-columns: 1fr 3fr 1fr;\n  }\n\n  .select-color {\n    grid-template-columns: 1fr 3fr 1fr;\n  }\n\n  .color-selected {\n    margin: 2% 0 2% 0;\n  }\n  .color-selected ion-label {\n    padding: 2em;\n  }\n\n  .img-preview-desktop {\n    display: none;\n  }\n\n  .img-preview-mobile {\n    display: flex;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb2xvci1zY2hlbWUtbW9kYWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBQTtFQUNBLDRCQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSw4QkFBQTtFQUNBLFdBQUE7QUFDSjs7QUFFQTs7Ozs7RUFLSSw2QkFBQTtFQUNBLDJCQUFBO0FBQ0o7O0FBRUE7RUFDSSw0QkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsOEJBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGlCQUFBO0FBQ0o7O0FBQUk7RUFDSSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUVSOztBQUVBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUFDSjs7QUFBSTtFQUNJLFlBQUE7RUFDQSxXQUFBO0FBRVI7O0FBQUk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQUVSOztBQUVBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0FBQ0o7O0FBQUk7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7QUFFUjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLGFBQUE7QUFDSjs7QUFBSTtFQUNJLCtCQUFBO0FBRVI7O0FBQUk7RUFDSSxxQkFBQTtBQUVSOztBQUFJO0VBQ0kscUJBQUE7QUFFUjs7QUFBSTtFQUNJLHFCQUFBO0FBRVI7O0FBQUk7RUFDSSxxQkFBQTtFQUNBLDhCQUFBO0FBRVI7O0FBQUk7RUFDSSx1QkFBQTtFQUNBLHFCQUFBO0FBRVI7O0FBRUE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtBQUNKOztBQUVBO0VBQ0ksaUNBQUE7QUFDSjs7QUFFQTtFQUNJLDhCQUFBO0FBQ0o7O0FBRUE7RUFDSTs7SUFFSSxZQUFBO0VBQ047QUFDRjs7QUFHQTtFQUNJO0lBQ0ksY0FBQTtJQUNBLGtCQUFBO0lBQ0EsTUFBQTtJQUNBLFdBQUE7RUFETjs7RUFJRTtJQUNJLGVBQUE7SUFDQSwyQkFBQTtJQUNBLDJCQUFBO0VBRE47O0VBSUU7SUFDSSxXQUFBO0VBRE47O0VBSUU7SUFDSSxrQ0FBQTtFQUROOztFQUlFO0lBQ0ksa0NBQUE7RUFETjs7RUFJRTtJQUlJLGlCQUFBO0VBSk47RUFDTTtJQUNJLFlBQUE7RUFDVjs7RUFJRTtJQUNJLGFBQUE7RUFETjs7RUFJRTtJQUNJLGFBQUE7RUFETjtBQUNGIiwiZmlsZSI6ImNvbG9yLXNjaGVtZS1tb2RhbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tb2RhbC10aXRsZSB7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi10ZXh0LWNvbG9yKTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmb250LXNpemU6IDEuMmVtO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBwYWRkaW5nOiA1JTtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQsXHJcbmlvbi1sYWJlbCxcclxuaW9uLWxpc3QsXHJcbmlvbi1saXN0LWhlYWRlcixcclxuaW9uLXJhZGlvLWdyb3VwIHtcclxuICAgIC0tYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uY29udGFpbmVyIHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tdGV4dC1jb2xvcik7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAyZnIgMmZyO1xyXG59XHJcblxyXG4uc2VsZWN0LWVzY2VuYSB7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMmZyO1xyXG4gICAgbWFyZ2luOiA1JSAwIDUlIDA7XHJcbiAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGFsaWduLXNlbGY6IGNlbnRlcjtcclxuICAgICAgICBmb250LXNpemU6IDEuMmVtO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxufVxyXG5cclxuLmVzY2VuYS10b2dnbGUge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLXRvZ2dsZSB7XHJcbiAgICAgICAgd2lkdGg6IDYwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG4uc2VsZWN0LWNvbG9yIHtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAyZnI7XHJcbiAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmb250LXNpemU6IDEuMmVtO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgfVxyXG59XHJcblxyXG4uY29sb3Itc2VsZWN0ZWQge1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDAuOGVtO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE2cHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIG1hcmdpbjogNCUgMCA0JSAwO1xyXG4gICAgdHJhbnNpdGlvbjogMC40cyBlYXNlO1xyXG4gICAgd2lkb3dzOiAxMDBweDtcclxuICAgIGlvbi1yYWRpbyB7XHJcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgIH1cclxuICAgICY6bnRoLWNoaWxkKDEpIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6ICM4NDE0RkY7XHJcbiAgICB9XHJcbiAgICAmOm50aC1jaGlsZCgyKSB7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjRkYzRTE0O1xyXG4gICAgfVxyXG4gICAgJjpudGgtY2hpbGQoMykge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogIzBBNjhCMjtcclxuICAgIH1cclxuICAgICY6bnRoLWNoaWxkKDQpIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6ICM0ZmZmNzU7XHJcbiAgICAgICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgfVxyXG4gICAgJjpob3ZlciB7XHJcbiAgICAgICAgZmlsdGVyOiBicmlnaHRuZXNzKDgwJSk7XHJcbiAgICAgICAgdHJhbnNpdGlvbjogMC40cyBlYXNlO1xyXG4gICAgfVxyXG59XHJcblxyXG4uaW1nLXByZXZpZXctZGVza3RvcCwgLmltZy1wcmV2aWV3LW1vYmlsZSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uaW1nLXByZXZpZXctbW9iaWxlIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcbmcgcmVjdDpudGgtY2hpbGQoMSkge1xyXG4gICAgZmlsbDogdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IpO1xyXG59XHJcblxyXG5nIHJlY3Qge1xyXG4gICAgZmlsbDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcblxyXG5Ac3VwcG9ydHMgbm90IChiYWNrZHJvcC1maWx0ZXI6IG5vbmUpIHtcclxuICAgIC5jb250YWluZXIsXHJcbiAgICAubW9kYWwtdGl0bGUge1xyXG4gICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIH1cclxufVxyXG5cclxuLy8gRm9yIG1vYmlsZSBkZXZpY2VzLlxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDc2N3B4KSB7XHJcbiAgICAubW9kYWwtdGl0bGUge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMWVtO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6IDA7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcblxyXG4gICAgLmNvbnRhaW5lciB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMTAlO1xyXG4gICAgICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogbm9uZTtcclxuICAgICAgICBncmlkLXRlbXBsYXRlLXJvd3M6IDJmciAyZnI7XHJcbiAgICB9XHJcblxyXG4gICAgLm9wdGlvbnMge1xyXG4gICAgICAgIGdyaWQtcm93OiAyO1xyXG4gICAgfVxyXG5cclxuICAgIC5zZWxlY3QtZXNjZW5hIHtcclxuICAgICAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAzZnIgMWZyO1xyXG4gICAgfVxyXG5cclxuICAgIC5zZWxlY3QtY29sb3Ige1xyXG4gICAgICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIDNmciAxZnI7XHJcbiAgICB9XHJcblxyXG4gICAgLmNvbG9yLXNlbGVjdGVkIHtcclxuICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAyZW07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG1hcmdpbjogMiUgMCAyJSAwO1xyXG4gICAgfVxyXG5cclxuICAgIC5pbWctcHJldmlldy1kZXNrdG9wIHtcclxuICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgfVxyXG5cclxuICAgIC5pbWctcHJldmlldy1tb2JpbGUge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICB9XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "KPGE":
    /*!**************************************************!*\
      !*** ./src/app/services/color-scheme.service.ts ***!
      \**************************************************/

    /*! exports provided: ColorSchemeService */

    /***/
    function KPGE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ColorSchemeService", function () {
        return ColorSchemeService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var color__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! color */
      "aSns");
      /* harmony import */


      var color__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(color__WEBPACK_IMPORTED_MODULE_3__);
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");

      var ColorSchemeService = /*#__PURE__*/function () {
        function ColorSchemeService(document, storage) {
          var _this = this;

          _classCallCheck(this, ColorSchemeService);

          this.document = document;
          this.storage = storage;
          storage.get('theme').then(function (cssText) {
            _this.setGlobalCSS(JSON.parse(cssText));
          });
        } // Override all global variables with a new theme


        _createClass(ColorSchemeService, [{
          key: "setTheme",
          value: function setTheme(theme, scene) {
            var cssText = themeGenerator(theme, scene);
            this.setGlobalCSS(cssText);
            this.storage.set('theme', JSON.stringify(cssText));
          } // Define a single CSS variable

        }, {
          key: "setVariable",
          value: function setVariable(name, value) {
            this.document.documentElement.style.setProperty(name, value);
          }
        }, {
          key: "setGlobalCSS",
          value: function setGlobalCSS(css) {
            this.document.documentElement.style.cssText = css;
          }
        }]);

        return ColorSchemeService;
      }();

      ColorSchemeService.ctorParameters = function () {
        return [{
          type: Document,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"],
            args: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["DOCUMENT"]]
          }]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"]
        }];
      };

      ColorSchemeService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ColorSchemeService);

      function themeGenerator(colors, scene) {
        colors = Object.assign({}, colors);
        scene = Object.assign({}, scene);
        var _colors = colors,
            primary = _colors.primary,
            secondary = _colors.secondary,
            tertiary = _colors.tertiary,
            success = _colors.success,
            warning = _colors.warning,
            danger = _colors.danger,
            dark = _colors.dark,
            medium = _colors.medium,
            light = _colors.light;
        var _scene = scene,
            bgColor = _scene.bgColor,
            color = _scene.color,
            toolbarBg = _scene.toolbarBg,
            toolbarTxt = _scene.toolbarTxt,
            itemBg = _scene.itemBg,
            itemTxt = _scene.itemTxt;
        var shadeRatio = 0.47;
        var tintRatio = 0.4;
        return "\n  --ion-color-primary: ".concat(primary, ";\n  --ion-color-primary-contrast: ").concat(contrast(primary), ";\n  --ion-color-primary-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(primary).darken(shadeRatio), ";\n  --ion-color-primary-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(primary).lighten(tintRatio), ";\n\n  --ion-color-secondary: ").concat(secondary, ";\n  --ion-color-secondary-contrast: ").concat(contrast(secondary), ";\n  --ion-color-secondary-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(secondary).darken(shadeRatio), ";\n  --ion-color-secondary-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(secondary).lighten(tintRatio), ";\n\n  --ion-color-tertiary: ").concat(tertiary, "; };\n  --ion-color-tertiary-contrast: ").concat(contrast(tertiary), ";\n  --ion-color-tertiary-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(tertiary).darken(shadeRatio), ";\n  --ion-color-tertiary-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(tertiary).lighten(tintRatio), ";\n\n  --ion-color-success: ").concat(success, ";\n  --ion-color-success-contrast: ").concat(contrast(success), ";\n  --ion-color-success-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(success).darken(shadeRatio), ";\n  --ion-color-success-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(success).lighten(tintRatio), ";\n\n  --ion-color-warning: ").concat(warning, ";\n  --ion-color-warning-contrast: ").concat(contrast(warning), ";\n  --ion-color-warning-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(warning).darken(shadeRatio), ";\n  --ion-color-warning-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(warning).lighten(tintRatio), ";\n\n  --ion-color-danger: ").concat(danger, ";\n  --ion-color-danger-contrast: ").concat(contrast(danger), ";\n  --ion-color-danger-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(danger).darken(shadeRatio), ";\n  --ion-color-danger-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(danger).lighten(tintRatio), ";\n\n  --ion-color-dark: ").concat(dark, ";\n  --ion-color-dark-contrast: ").concat(contrast(dark), ";\n  --ion-color-dark-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(dark).darken(shadeRatio), ";\n  --ion-color-dark-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(dark).lighten(tintRatio), ";\n\n  --ion-color-medium: ").concat(medium, ";\n  --ion-color-medium-contrast: ").concat(contrast(medium), ";\n  --ion-color-medium-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(medium).darken(shadeRatio), ";\n  --ion-color-medium-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(medium).lighten(tintRatio), ";\n\n  --ion-color-light: ").concat(light, ";\n  --ion-color-light-contrast: $").concat(contrast(light), ";\n  --ion-color-light-contrast-rgb: 0,0,0;\n  --ion-color-light-shade: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(light).darken(shadeRatio), ";\n  --ion-color-light-tint: ").concat(color__WEBPACK_IMPORTED_MODULE_3__(light).lighten(tintRatio), ";\n\n  --ion-background-color: ").concat(bgColor, ";\n  --ion-text-color: ").concat(color, ";\n  --ion-toolbar-background-color: ").concat(toolbarBg, ";\n  --ion-toolbar-text-color: ").concat(toolbarTxt, ";\n  --ion-item-background-color: ").concat(itemBg, ";\n  --ion-item-text-color: ").concat(itemTxt, ";\n\n  ");
      }

      function contrast(color) {
        var ratio = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0.8;
        color = color__WEBPACK_IMPORTED_MODULE_3__(color);
        return color.isDark() ? color.lighten(ratio) : color.darken(ratio);
      }
      /***/

    },

    /***/
    "MMy8":
    /*!******************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/color-scheme-modal/color-scheme-modal.component.html ***!
      \******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function MMy8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"modal-title\">\n  <ion-tile>\n      Cambiar el tema\n  </ion-tile>\n  <ion-button color=\"danger\" (click)=\"closeModal()\">Cerrar</ion-button>\n</div>\n\n<div class=\"container\">\n  <div class=\"options\">\n    <div class=\"select-escena\">\n      <ion-label>Escena</ion-label>\n      <div class=\"escena-toggle\">\n        <ion-icon name=\"sunny-sharp\"></ion-icon>\n        <ion-toggle (ionChange)=\"setScene($event)\" checked=\"{{ sceneValue }}\"></ion-toggle>\n      <ion-icon name=\"moon-sharp\"></ion-icon>\n      </div>\n    </div>\n\n    <ion-list class=\"select-color\">\n      <ion-label>Color</ion-label>\n      <ion-radio-group value=\"{{ themeValue }}\">\n        <ion-item class=\"color-selected\" (click)=\"setTheme('normal')\">\n          <ion-label>Normal</ion-label>\n          <ion-radio slot=\"start\" color=\"light\" value=\"normal\"></ion-radio>\n        </ion-item>\n        <ion-item class=\"color-selected\" (click)=\"setTheme('redpilled')\">\n          <ion-label>Redpilado</ion-label>\n          <ion-radio slot=\"start\" color=\"light\" value=\"redpilled\"></ion-radio>\n        </ion-item>\n        <ion-item class=\"color-selected\" (click)=\"setTheme('dexov')\">\n          <ion-label>Dexov</ion-label>\n          <ion-radio slot=\"start\" color=\"light\" value=\"dexov\"></ion-radio>\n        </ion-item>\n        <ion-item class=\"color-selected\" (click)=\"setTheme('verza')\">\n          <ion-label>Verza</ion-label>\n          <ion-radio slot=\"start\" color=\"dark\" value=\"verza\"></ion-radio>\n        </ion-item>\n      </ion-radio-group>\n    </ion-list>\n  </div>\n\n<!-- Color scheme image preview in Desktop.-->\n  <div class=\"img-preview-desktop\">\n    <svg width=\"240\" height=\"145\" viewBox=\"0 0 240 145\" fill=\"none\">\n      <g>\n      <rect width=\"240\" height=\"145\" rx=\"8\"/>\n      <rect x=\"12\" y=\"38.9785\" width=\"51.4286\" height=\"40.5376\"/>\n      <rect x=\"94.2856\" y=\"38.9785\" width=\"51.4286\" height=\"40.5376\"/>\n      <rect x=\"94.2856\" y=\"91.9893\" width=\"51.4286\" height=\"41.3172\"/>\n      <rect x=\"174\" y=\"91.9893\" width=\"51.4286\" height=\"41.3172\"/>\n      <rect x=\"174\" y=\"38.9785\" width=\"51.4286\" height=\"40.5376\"/>\n      <rect x=\"12\" y=\"91.9893\" width=\"51.4286\" height=\"41.3172\"/>\n      <rect width=\"22.2857\" height=\"20.2688\" transform=\"matrix(-1 0 0 1 34.2856 6.23657)\"/>\n      <rect width=\"79.7143\" height=\"20.2688\" transform=\"matrix(-1 0 0 1 225.429 6.23657)\"/>\n      </g>\n    </svg>\n  </div>\n\n<!-- Color scheme image preview in Mobile.-->\n  <div class=\"img-preview-mobile\">\n    <svg width=\"120\" height=\"228\" viewBox=\"0 0 120 228\" fill=\"none\">\n      <g>\n      <rect width=\"120\" height=\"227.919\"/>\n      <rect x=\"7.24805\" y=\"73.2888\" width=\"48.3221\" height=\"41.8792\"/>\n      <rect x=\"7.24805\" y=\"11.2751\" width=\"48.3221\" height=\"41.8792\"/>\n      <rect x=\"7.24805\" y=\"135.302\" width=\"48.3221\" height=\"41.8792\"/>\n      <rect x=\"63.6245\" y=\"73.2888\" width=\"48.3221\" height=\"41.8792\"/>\n      <rect x=\"63.6245\" y=\"11.2751\" width=\"48.3221\" height=\"41.8792\"/>\n      <rect x=\"63.6245\" y=\"135.302\" width=\"48.3221\" height=\"41.8792\"/>\n      <rect width=\"20.9396\" height=\"20.9396\" transform=\"matrix(-1 0 0 1 28.188 195.705)\"/>\n      <rect width=\"56.3758\" height=\"20.9396\" transform=\"matrix(-1 0 0 1 111.946 195.705)\"/>\n      </g>  \n    </svg>\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "Sy1n":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function Sy1n(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./app.component.html */
      "VzVu");
      /* harmony import */


      var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app.component.scss */
      "ynWL");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "54vc");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "VYYF");
      /* harmony import */


      var _services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./services/auth.service */
      "lGQG");
      /* harmony import */


      var _pages_color_scheme_modal_color_scheme_modal_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./pages/color-scheme-modal/color-scheme-modal.component */
      "xOzW");
      /* harmony import */


      var _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./services/color-scheme.service */
      "KPGE");

      var AppComponent = /*#__PURE__*/function () {
        function AppComponent(platform, splashScreen, statusBar, authServ, toastCtrl, modalCtrl, theme) {
          _classCallCheck(this, AppComponent);

          this.platform = platform;
          this.splashScreen = splashScreen;
          this.statusBar = statusBar;
          this.authServ = authServ;
          this.toastCtrl = toastCtrl;
          this.modalCtrl = modalCtrl;
          this.theme = theme;
          this.selectedIndex = 0;
          this.appPages = [{
            title: 'General',
            url: '/off',
            icon: 'grid'
          }, {
            title: 'Preguntas',
            url: '/prg',
            icon: 'help'
          }, {
            title: 'Música',
            url: '/mus',
            icon: 'musical-notes'
          }, {
            title: 'Cine',
            url: '/cin',
            icon: 'videocam'
          }, {
            title: 'Ciencia y tecnología',
            url: '/sci',
            icon: 'terminal'
          }, {
            title: 'Historia',
            url: '/his',
            icon: 'book'
          }, {
            title: 'Política',
            url: '/pol',
            icon: 'megaphone'
          }, {
            title: 'Arte',
            url: '/art',
            icon: 'brush'
          }, {
            title: 'Normie',
            url: '/nor',
            icon: 'walk'
          }, {
            title: 'Random',
            url: '/uff',
            icon: 'dice'
          }, {
            title: 'Anime',
            url: '/anm',
            icon: 'transgender'
          }];
          this.initializeApp();
        }

        _createClass(AppComponent, [{
          key: "initializeApp",
          value: function initializeApp() {
            var _this2 = this;

            this.platform.ready().then(function () {
              _this2.statusBar.styleDefault();

              _this2.splashScreen.hide();
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            var path = window.location.pathname;

            if (path !== undefined) {
              this.selectedIndex = this.appPages.findIndex(function (page) {
                return page.title.toLowerCase() === path.toLowerCase();
              });
            }
          }
        }, {
          key: "googleSignin",
          value: function googleSignin() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this3 = this;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.authServ.googleSignin().then(function (_) {
                        return _this3.toastCtrl.create({
                          header: 'Sesión iniciada correctamente',
                          position: 'top',
                          duration: 4000
                        }).then(function (toast) {
                          return toast.present();
                        });
                      })["catch"](function (_) {
                        return _this3.toastCtrl.create({
                          header: 'No tenes permisos de moderación',
                          position: 'top',
                          duration: 4000
                        }).then(function (toast) {
                          return toast.present();
                        });
                      });

                    case 2:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "googleSignout",
          value: function googleSignout() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.authServ.signOut();

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          } // Color Scheme Changer function.

        }, {
          key: "changeColorScheme",
          value: function changeColorScheme() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var modal;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.modalCtrl.create({
                        component: _pages_color_scheme_modal_color_scheme_modal_component__WEBPACK_IMPORTED_MODULE_8__["ColorSchemeModalPage"],
                        cssClass: 'color-scheme-changer-modal'
                      });

                    case 2:
                      modal = _context3.sent;
                      _context3.next = 5;
                      return modal.present();

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }]);

        return AppComponent;
      }();

      AppComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"]
        }, {
          type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"]
        }, {
          type: _services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }, {
          type: _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_9__["ColorSchemeService"]
        }];
      };

      AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], AppComponent);
      /***/
    },

    /***/
    "VzVu":
    /*!**************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
      \**************************************************************************/

    /*! exports provided: default */

    /***/
    function VzVu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-app>\r\n  <ion-split-pane contentId=\"main-content\" disabled=\"true\">\r\n    <ion-menu contentId=\"main-content\" type=\"overlay\">\r\n      <ion-content>\r\n        <div class=\"logo\">\r\n          <img src=\"../assets/icon/logo.svg\" alt=\"\">\r\n          <h1>Anon land</h1>\r\n          <p>Expresate anoninamente</p>\r\n        </div>\r\n        <ion-list id=\"inbox-list\">\r\n          <ion-list-header class=\"ion-padding\">Nichos</ion-list-header>\r\n\r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\r\n            <ion-item (click)=\"selectedIndex = i\" routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\"\r\n              detail=\"false\" [class.selected]=\"selectedIndex == i\">\r\n              <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\r\n              <ion-label>{{ p.title }}</ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n        </ion-list>\r\n\r\n        <ion-menu-toggle auto-hide=\"false\" [hidden]=\"this.authServ.user != undefined\">\r\n          <ion-item (click)=\"googleSignin()\" class=\"pointer\" routerDirection=\"root\" lines=\"none\" detail=\"false\">\r\n            <ion-icon slot=\"start\" ios=\"log-in-outline\" md=\"log-in-sharp\"></ion-icon>\r\n            <ion-label>Iniciar sesión (Mod)</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle auto-hide=\"false\" [hidden]=\"this.authServ.user == undefined\">\r\n          <ion-item (click)=\"googleSignout()\" class=\"pointer\" routerDirection=\"root\" lines=\"none\" detail=\"false\">\r\n            <ion-icon slot=\"start\" ios=\"log-out-outline\" md=\"log-out-sharp\"></ion-icon>\r\n            <ion-label>Cerrar sesión (Mod)</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle auto-hide=\"false\" *ngIf=\"this.authServ.user\">\r\n          <ion-item class=\"pointer\" routerDirection=\"root\" [routerLink]=\"['/admins']\" lines=\"none\" detail=\"false\">\r\n            <ion-icon slot=\"start\" ios=\"hammer-outline\" md=\"hammer-sharp\"></ion-icon>\r\n            <ion-label>Admin Cpanel</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle auto-hide=\"true\">\r\n          <ion-item (click)=\"changeColorScheme()\" class=\"pointer color-scheme\">\r\n            <ion-icon slot=\"start\" ios=\"color-palette-outline\" md=\"color-palette-sharp\"></ion-icon>\r\n            <ion-label>Cambiar el tema</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n      </ion-content>\r\n    </ion-menu>\r\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\r\n  </ion-split-pane>\r\n</ion-app>\r\n";
      /***/
    },

    /***/
    "ZAI4":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function ZAI4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "54vc");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "VYYF");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./app-routing.module */
      "vY5A");
      /* harmony import */


      var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/fire/firestore */
      "I/3d");
      /* harmony import */


      var _angular_fire__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/fire */
      "spgP");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _angular_fire__WEBPACK_IMPORTED_MODULE_10__["AngularFireModule"].initializeApp(src_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].firebaseConfig), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"], _ionic_storage__WEBPACK_IMPORTED_MODULE_13__["IonicStorageModule"].forRoot()],
        providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_9__["AngularFirestore"], {
          provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
          useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
        }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
      })], AppModule);
      /***/
    },

    /***/
    "kLfG":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \*****************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function kLfG(module, exports, __webpack_require__) {
      var map = {
        "./ion-action-sheet.entry.js": ["dUtr", "common", 0],
        "./ion-alert.entry.js": ["Q8AI", "common", 1],
        "./ion-app_8.entry.js": ["hgI1", "common", 2],
        "./ion-avatar_3.entry.js": ["CfoV", "common", 3],
        "./ion-back-button.entry.js": ["Nt02", "common", 4],
        "./ion-backdrop.entry.js": ["Q2Bp", 5],
        "./ion-button_2.entry.js": ["0Pbj", "common", 6],
        "./ion-card_5.entry.js": ["ydQj", "common", 7],
        "./ion-checkbox.entry.js": ["4fMi", "common", 8],
        "./ion-chip.entry.js": ["czK9", "common", 9],
        "./ion-col_3.entry.js": ["/CAe", 10],
        "./ion-datetime_3.entry.js": ["WgF3", "common", 11],
        "./ion-fab_3.entry.js": ["uQcF", "common", 12],
        "./ion-img.entry.js": ["wHD8", 13],
        "./ion-infinite-scroll_2.entry.js": ["2lz6", 14],
        "./ion-input.entry.js": ["ercB", "common", 15],
        "./ion-item-option_3.entry.js": ["MGMP", "common", 16],
        "./ion-item_8.entry.js": ["9bur", "common", 17],
        "./ion-loading.entry.js": ["cABk", "common", 18],
        "./ion-menu_3.entry.js": ["kyFE", "common", 19],
        "./ion-modal.entry.js": ["TvZU", "common", 20],
        "./ion-nav_2.entry.js": ["vnES", "common", 21],
        "./ion-popover.entry.js": ["qCuA", "common", 22],
        "./ion-progress-bar.entry.js": ["0tOe", "common", 23],
        "./ion-radio_2.entry.js": ["h11V", "common", 24],
        "./ion-range.entry.js": ["XGij", "common", 25],
        "./ion-refresher_2.entry.js": ["nYbb", "common", 26],
        "./ion-reorder_2.entry.js": ["smMY", "common", 27],
        "./ion-ripple-effect.entry.js": ["STjf", 28],
        "./ion-route_4.entry.js": ["k5eQ", "common", 29],
        "./ion-searchbar.entry.js": ["OR5t", "common", 30],
        "./ion-segment_2.entry.js": ["fSgp", "common", 31],
        "./ion-select_3.entry.js": ["lfGF", "common", 32],
        "./ion-slide_2.entry.js": ["5xYT", 33],
        "./ion-spinner.entry.js": ["nI0H", "common", 34],
        "./ion-split-pane.entry.js": ["NAQR", 35],
        "./ion-tab-bar_2.entry.js": ["knkW", "common", 36],
        "./ion-tab_2.entry.js": ["TpdJ", "common", 37],
        "./ion-text.entry.js": ["ISmu", "common", 38],
        "./ion-textarea.entry.js": ["U7LX", "common", 39],
        "./ion-toast.entry.js": ["L3sA", "common", 40],
        "./ion-toggle.entry.js": ["IUOf", "common", 41],
        "./ion-virtual-scroll.entry.js": ["8Mb5", 42]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "kLfG";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "lGQG":
    /*!******************************************!*\
      !*** ./src/app/services/auth.service.ts ***!
      \******************************************/

    /*! exports provided: AuthService */

    /***/
    function lGQG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AuthService", function () {
        return AuthService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/fire/auth */
      "UbJi");
      /* harmony import */


      var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/fire/firestore */
      "I/3d");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var firebase_app__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! firebase/app */
      "Jgta");

      var AuthService = /*#__PURE__*/function () {
        function AuthService(afAuth, afs, router) {
          var _this4 = this;

          _classCallCheck(this, AuthService);

          this.afAuth = afAuth;
          this.afs = afs;
          this.router = router;
          this.afAuth.onAuthStateChanged(function (user) {
            return _this4.user = user;
          });
        } // Sign in with Google


        _createClass(AuthService, [{
          key: "googleSignin",
          value: function googleSignin() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var provider, credential;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      provider = new firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth.GoogleAuthProvider();
                      _context4.next = 3;
                      return this.afAuth.signInWithPopup(provider);

                    case 3:
                      credential = _context4.sent;
                      this.afAuth.setPersistence(firebase_app__WEBPACK_IMPORTED_MODULE_5__["default"].auth.Auth.Persistence.LOCAL);
                      _context4.next = 7;
                      return this.getModProfile(credential.user.email);

                    case 7:
                      this.user = _context4.sent;

                    case 8:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "getModProfile",
          value: function getModProfile(email) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var data;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      _context5.next = 2;
                      return this.afs.collection('mods', function (ref) {
                        return ref.where('email', '==', email);
                      }).get().toPromise();

                    case 2:
                      data = _context5.sent;

                      if (!(!data || data.empty)) {
                        _context5.next = 6;
                        break;
                      }

                      this.user = undefined;
                      throw new Error('Usuario no registrado como mod');

                    case 6:
                      return _context5.abrupt("return", data.docs[0].data());

                    case 7:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "getToken",
          value: function getToken() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      _context6.next = 2;
                      return this.afAuth.currentUser;

                    case 2:
                      return _context6.abrupt("return", _context6.sent.getIdToken(true));

                    case 3:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "signOut",
          value: function signOut() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      _context7.next = 2;
                      return this.afAuth.signOut();

                    case 2:
                      this.user = undefined;
                      this.router.navigate(['/']);

                    case 4:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }]);

        return AuthService;
      }();

      AuthService.ctorParameters = function () {
        return [{
          type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_2__["AngularFireAuth"]
        }, {
          type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_3__["AngularFirestore"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
        }];
      };

      AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AuthService);
      /***/
    },

    /***/
    "vY5A":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function vY5A(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var routes = [{
        path: '',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | pages-main-main-module */
          [__webpack_require__.e("default~pages-main-main-module~pages-post-post-module"), __webpack_require__.e("pages-main-main-module")]).then(__webpack_require__.bind(null,
          /*! ./pages/main/main.module */
          "82nU")).then(function (m) {
            return m.MainPageModule;
          });
        }
      }, {
        path: ':category',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | pages-main-main-module */
          [__webpack_require__.e("default~pages-main-main-module~pages-post-post-module"), __webpack_require__.e("pages-main-main-module")]).then(__webpack_require__.bind(null,
          /*! ./pages/main/main.module */
          "82nU")).then(function (m) {
            return m.MainPageModule;
          });
        }
      }, {
        path: ':category/:postId',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | pages-post-post-module */
          [__webpack_require__.e("default~pages-main-main-module~pages-post-post-module"), __webpack_require__.e("pages-post-post-module")]).then(__webpack_require__.bind(null,
          /*! ./pages/post/post.module */
          "gDdP")).then(function (m) {
            return m.PostPageModule;
          });
        }
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
          preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"]
        })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AppRoutingModule);
      /***/
    },

    /***/
    "xOzW":
    /*!**************************************************************************!*\
      !*** ./src/app/pages/color-scheme-modal/color-scheme-modal.component.ts ***!
      \**************************************************************************/

    /*! exports provided: ColorSchemeModalPage */

    /***/
    function xOzW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ColorSchemeModalPage", function () {
        return ColorSchemeModalPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_color_scheme_modal_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./color-scheme-modal.component.html */
      "MMy8");
      /* harmony import */


      var _color_scheme_modal_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./color-scheme-modal.component.scss */
      "Fadn");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../services/color-scheme.service */
      "KPGE");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1"); // Themes.


      var themes = {
        normal: {
          primary: '#8414FF',
          secondary: '#A55CF6',
          tertiary: '#DEEFB7',
          success: '#2dd36f',
          warning: '#F29559',
          danger: '#eb445a',
          light: '#FEFFFC',
          medium: '#D8D7D6',
          dark: '#270250'
        },
        redpilled: {
          primary: '#FF3E14',
          secondary: '#61a0af',
          tertiary: '#f5d491',
          success: '#21cf3f',
          warning: '#FFD911',
          danger: '#FF1167',
          light: '#FEFFFC',
          medium: '#D8D7D6',
          dark: '#550101'
        },
        dexov: {
          primary: '#2d6fbd',
          secondary: '#055999',
          tertiary: '#356285',
          success: '#0AB24D',
          warning: '#FFD911',
          danger: '#eb445a',
          light: '#FEFFFC',
          medium: '#D8D7D6',
          dark: '#012646'
        },
        verza: {
          primary: '#4fff75',
          secondary: '#57c66f',
          tertiary: '#E0C6F5',
          success: '#22CA7A',
          warning: '#FFD911',
          danger: '#FF1167',
          light: '#FEFFFC',
          medium: '#D8D7D6',
          dark: '#013500'
        }
      }; // Scene.

      var scene = {
        day: {
          bgColor: '#FFFFFF',
          color: '#000000',
          toolbarBg: '#F4F4F4',
          toolbarTxt: '#222222',
          itemBg: '#EEEEEE',
          itemTxt: '#555555'
        },
        night: {
          bgColor: '#000000',
          color: '#FFFFFF',
          toolbarBg: '#222222',
          toolbarTxt: '#F4F4F4',
          itemBg: '#444444',
          itemTxt: '#EEEEEE'
        }
      };

      var ColorSchemeModalPage = /*#__PURE__*/function () {
        function ColorSchemeModalPage(modalCtrl, theme, storage) {
          _classCallCheck(this, ColorSchemeModalPage);

          this.modalCtrl = modalCtrl;
          this.theme = theme;
          this.storage = storage; // TODO: improve the set theme function and avoid boilerplate code.
          // Defaults options.

          this.sceneName = 'day';
        }

        _createClass(ColorSchemeModalPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.getThemeValue();
            this.getSceneValue();
          }
        }, {
          key: "getThemeValue",
          value: function getThemeValue() {
            var _this5 = this;

            this.storage.get('themeName').then(function (value) {
              if (value == null) {
                _this5.themeValue = 'normal';
              } else {
                _this5.themeValue = value;
              }
            });
          }
        }, {
          key: "getSceneValue",
          value: function getSceneValue() {
            var _this6 = this;

            this.storage.get('sceneStatus').then(function (value) {
              if (value == null) {
                _this6.sceneValue = false;
              } else {
                _this6.sceneValue = value;
              }
            });
          } // Switch scene mode between day and night.

        }, {
          key: "setScene",
          value: function setScene(event) {
            var status = event.detail.checked;

            if (status) {
              this.sceneName = 'night';
            } else {
              this.sceneName = 'day';
            }

            this.theme.setTheme(themes[this.themeValue], scene[this.sceneName]);
            this.storage.set('sceneStatus', JSON.stringify(status));
          } // Change color scheme.

        }, {
          key: "setTheme",
          value: function setTheme(themeName) {
            this.themeValue = themeName;
            this.theme.setTheme(themes[this.themeValue], scene[this.sceneName]);
            this.storage.set('themeName', this.themeValue);
          } // Close modal.

        }, {
          key: "closeModal",
          value: function closeModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      _context8.next = 2;
                      return this.modalCtrl.dismiss();

                    case 2:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this);
            }));
          }
        }]);

        return ColorSchemeModalPage;
      }();

      ColorSchemeModalPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
        }, {
          type: _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_5__["ColorSchemeService"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]
        }];
      };

      ColorSchemeModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-color-scheme-modal',
        template: _raw_loader_color_scheme_modal_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_color_scheme_modal_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ColorSchemeModalPage);
      /***/
    },

    /***/
    "ynWL":
    /*!************************************!*\
      !*** ./src/app/app.component.scss ***!
      \************************************/

    /*! exports provided: default */

    /***/
    function ynWL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\n.logo {\n  margin-top: 50px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n}\n\n.logo img {\n  width: 80px;\n}\n\n.logo p {\n  margin: 0;\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 3px solid var(--ion-item-background-color);\n  border: 50%;\n}\n\n.color-scheme {\n  --inner-border-width: 0;\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 16px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\n.pointer {\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsMkVBQUE7QUFDRjs7QUFFQTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFBSTtFQUNFLFdBQUE7QUFFTjs7QUFBSTtFQUNFLFNBQUE7QUFFTjs7QUFFQTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTs7RUFFRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UseURBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBRUEsZ0JBQUE7QUFBRjs7QUFHQTtFQUNFLGVBQUE7RUFFQSxtQkFBQTtFQUVBLGNBQUE7RUFFQSxnQkFBQTtBQUhGOztBQU1BO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxzREFBQTtBQUhGOztBQU1BO0VBQ0UsK0JBQUE7QUFIRjs7QUFNQTtFQUNFLGNBQUE7QUFIRjs7QUFNQTtFQUNFLGdCQUFBO0FBSEY7O0FBTUE7RUFDRSxzQkFBQTtBQUhGOztBQU1BO0VBQ0UsbUJBQUE7QUFIRjs7QUFNQTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhGOztBQU1BO0VBQ0UsK0JBQUE7QUFIRjs7QUFNQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBSEY7O0FBTUE7RUFDRSxrQkFBQTtBQUhGOztBQU1BOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7QUFIRjs7QUFNQTtFQUNFLGtCQUFBO0FBSEY7O0FBTUE7RUFDRSxxQkFBQTtFQUNBLGVBQUE7RUFFQSxvQ0FBQTtBQUpGOztBQU9BO0VBQ0UsaUNBQUE7QUFKRjs7QUFPQTtFQUNFLGVBQUE7QUFKRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudSBpb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xyXG59XHJcblxyXG4ubG9nbyB7XHJcbiAgbWFyZ2luLXRvcDogNTBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiA4MHB4O1xyXG4gICAgfVxyXG4gICAgcCB7XHJcbiAgICAgIG1hcmdpbjogMDtcclxuICAgIH1cclxufVxyXG5cclxuaW9uLW1lbnUubWQgaW9uLWNvbnRlbnQge1xyXG4gIC0tcGFkZGluZy1zdGFydDogOHB4O1xyXG4gIC0tcGFkZGluZy1lbmQ6IDhweDtcclxuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xyXG59XHJcblxyXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxufVxyXG5cclxuaW9uLW1lbnUubWQgaW9uLWxpc3QtaGVhZGVyLFxyXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XHJcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG59XHJcblxyXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcclxuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgdmFyKC0taW9uLWl0ZW0tYmFja2dyb3VuZC1jb2xvcik7XHJcbiAgYm9yZGVyOiA1MCU7XHJcbn1cclxuXHJcbi5jb2xvci1zY2hlbWUge1xyXG4gIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwO1xyXG59XHJcblxyXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IGlvbi1saXN0LWhlYWRlciB7XHJcbiAgZm9udC1zaXplOiAyMnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcblxyXG4gIG1pbi1oZWlnaHQ6IDIwcHg7XHJcbn1cclxuXHJcbmlvbi1tZW51Lm1kIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG5cclxuICBtYXJnaW4tYm90dG9tOiAxOHB4O1xyXG5cclxuICBjb2xvcjogIzc1NzU3NTtcclxuXHJcbiAgbWluLWhlaWdodDogMjZweDtcclxufVxyXG5cclxuaW9uLW1lbnUubWQgaW9uLWl0ZW0ge1xyXG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcclxuICAtLXBhZGRpbmctZW5kOiAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDE2cHg7XHJcbn1cclxuXHJcbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcclxuICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiKSwgMC4xNCk7XHJcbn1cclxuXHJcbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcblxyXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XHJcbiAgY29sb3I6ICM2MTZlN2U7XHJcbn1cclxuXHJcbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxufVxyXG5cclxuaW9uLW1lbnUuaW9zIGlvbi1jb250ZW50IHtcclxuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xyXG59XHJcblxyXG5pb24tbWVudS5pb3MgaW9uLWxpc3Qge1xyXG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XHJcbn1cclxuXHJcbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XHJcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG5cclxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcclxuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XHJcbiAgLS1wYWRkaW5nLWVuZDogMTZweDtcclxuICAtLW1pbi1oZWlnaHQ6IDUwcHg7XHJcbn1cclxuXHJcbmlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XHJcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxufVxyXG5cclxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgY29sb3I6ICM3Mzg0OWE7XHJcbn1cclxuXHJcbmlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xyXG4gIG1hcmdpbi1ib3R0b206IDhweDtcclxufVxyXG5cclxuaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcclxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcclxuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XHJcbiAgcGFkZGluZy1yaWdodDogMTZweDtcclxufVxyXG5cclxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcclxuICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbn1cclxuXHJcbmlvbi1ub3RlIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG5cclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XHJcbn1cclxuXHJcbmlvbi1pdGVtLnNlbGVjdGVkIHtcclxuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbn1cclxuXHJcbi5wb2ludGVyIHtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "zUnb":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function zUnb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/platform-browser-dynamic */
      "a3Wg");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "ZAI4");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environments/environment */
      "AytR");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.log(err);
      });
      /***/
    },

    /***/
    "zn8P":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function zn8P(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "zn8P";
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map