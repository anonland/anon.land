(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-main-main-module"], {
    /***/
    "/ie9":
    /*!*******************************************************************!*\
      !*** ./src/app/components/post-options/post-options.component.ts ***!
      \*******************************************************************/

    /*! exports provided: PostOptionsComponent */

    /***/
    function ie9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PostOptionsComponent", function () {
        return PostOptionsComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_post_options_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./post-options.component.html */
      "wao6");
      /* harmony import */


      var _post_options_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./post-options.component.scss */
      "p96T");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");
      /* harmony import */


      var src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/helpers/functions */
      "3crM");

      var PostOptionsComponent = /*#__PURE__*/function () {
        function PostOptionsComponent(http, toastCtrl, popoverCtrl, storage) {
          _classCallCheck(this, PostOptionsComponent);

          this.http = http;
          this.toastCtrl = toastCtrl;
          this.popoverCtrl = popoverCtrl;
          this.storage = storage;
        }

        _createClass(PostOptionsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {} // Report a post sending the postId.

        }, {
          key: "report",
          value: function report() {
            var _this = this;

            this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_7__["createUrl"])('report'), {
              postID: this.postId
            }, {
              responseType: 'text'
            }).subscribe(function () {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var toast;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return this.toastCtrl.create({
                          header: 'El post fue reportado.',
                          position: 'top'
                        });

                      case 2:
                        toast = _context.sent;
                        _context.next = 5;
                        return toast.present();

                      case 5:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            });
            this.popoverCtrl.dismiss();
          } // Hide a post per postId and save as index in IonStorage,

        }, {
          key: "hide",
          value: function hide() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var post, postImg, id;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      post = document.querySelector("#post_".concat(this.postId));
                      postImg = document.querySelector("#post_".concat(this.postId, " + img"));
                      post.style.display = 'flex';
                      postImg.style.display = 'none'; // Dismiss options.

                      this.popoverCtrl.dismiss(); // Save the post.

                      _context2.next = 7;
                      return this.storage.get('hiddenPostId');

                    case 7:
                      id = _context2.sent;

                      if (!id) {
                        _context2.next = 13;
                        break;
                      }

                      id.push(this.postId);
                      return _context2.abrupt("return", this.storage.set('hiddenPostId', id));

                    case 13:
                      return _context2.abrupt("return", this.storage.set('hiddenPostId', [this.postId]));

                    case 14:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return PostOptionsComponent;
      }();

      PostOptionsComponent.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]
        }];
      };

      PostOptionsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-post-options',
        template: _raw_loader_post_options_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_post_options_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PostOptionsComponent);
      /***/
    },

    /***/
    "82nU":
    /*!*******************************************!*\
      !*** ./src/app/pages/main/main.module.ts ***!
      \*******************************************/

    /*! exports provided: MainPageModule */

    /***/
    function nU(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MainPageModule", function () {
        return MainPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _main_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./main-routing.module */
      "TIEH");
      /* harmony import */


      var _main_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./main.page */
      "TQIn");
      /* harmony import */


      var _new_post_new_post_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../new-post/new-post.page */
      "ccyQ");
      /* harmony import */


      var src_app_pipes_full_category_pipe__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! src/app/pipes/full-category.pipe */
      "lzmV");

      var MainPageModule = function MainPageModule() {
        _classCallCheck(this, MainPageModule);
      };

      MainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _main_routing_module__WEBPACK_IMPORTED_MODULE_5__["MainPageRoutingModule"]],
        declarations: [_main_page__WEBPACK_IMPORTED_MODULE_6__["MainPage"], _new_post_new_post_page__WEBPACK_IMPORTED_MODULE_7__["NewPostPage"], src_app_pipes_full_category_pipe__WEBPACK_IMPORTED_MODULE_8__["FullCategoryPipe"]]
      })], MainPageModule);
      /***/
    },

    /***/
    "8rh1":
    /*!*******************************************!*\
      !*** ./src/app/pages/main/main.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function rh1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-tittle,\nion-button,\nion-icon {\n  font-weight: bolder;\n}\n\nion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n.create-post {\n  display: flex;\n  justify-content: space-between;\n  width: 15vw;\n}\n\n.create-post p {\n  margin-right: 5%;\n}\n\nion-badge {\n  padding: 4px;\n}\n\nion-badge ion-icon {\n  font-size: 11.62px;\n}\n\n.options-badge {\n  position: absolute !important;\n  right: 0px;\n  top: 0px;\n}\n\n.container {\n  display: grid;\n  grid-template-columns: 1fr 1fr 1fr 1fr 1fr;\n  grid-template-rows: 1fr 1fr 1fr 1fr 1fr;\n  aspect-ratio: 1;\n}\n\n.main-post-img {\n  background-color: var(--ion-background-color);\n  background-repeat: no-repeat;\n  background-size: cover;\n  border: 1px solid var(--ion-toolbar-background-color);\n  cursor: pointer;\n  display: flex;\n  font-weight: bold;\n  color: white;\n  -o-object-fit: cover;\n     object-fit: cover;\n  overflow: hidden;\n}\n\n.main-post-img .show-post {\n  align-items: center;\n  background-color: var(--ion-toolbar-background-color);\n  cursor: pointer;\n  display: none;\n  flex-direction: row;\n  font-size: 1.3em;\n  font-weight: bold;\n  height: 100%;\n  justify-content: space-evenly;\n  width: 100%;\n  z-index: 10;\n}\n\n.main-post-img .show-post .show-post-title {\n  font-family: \"Visby Round CF\";\n  font-weight: bold;\n  opacity: 60%;\n  transition: 0.4s ease;\n}\n\n.main-post-img .show-post:hover .show-post-title {\n  opacity: 100%;\n  transition: 0.4s ease;\n}\n\n.main-post-img img {\n  -o-object-fit: cover;\n     object-fit: cover;\n  width: 100%;\n}\n\n.main-post-img .content {\n  position: absolute;\n  padding: 1em;\n}\n\n.main-post-img .content .options {\n  margin-right: 1%;\n}\n\n.main-post-img .content h1 {\n  font-size: 1em;\n  font-weight: bold;\n  margin: 0;\n}\n\n.image {\n  border-radius: 0;\n  filter: grayscale(60%);\n  transform: scale(1);\n  transition: 0.4s ease;\n}\n\n.main-post-img:hover .image {\n  border-radius: 1em;\n  filter: grayscale(0%);\n  transform: scale(0.95);\n  transition: 0.4s ease;\n  box-shadow: -6px -68px 79px -37px rgba(0, 0, 0, 0.59) inset;\n}\n\n.information {\n  width: 200px;\n}\n\n.post-text {\n  position: absolute;\n}\n\n.end {\n  background-color: var(--ion-toolbar-background-color);\n  color: var(--ion-text-color);\n  display: grid;\n  font-weight: bold;\n  font-size: 1em;\n  place-content: center;\n  position: relative;\n  width: 100vw;\n  height: 20vh;\n}\n\n.scroll-top {\n  align-items: center;\n  background-color: var(--ion-color-tertiary);\n  bottom: 8vh;\n  color: var(--ion-item-background-color);\n  cursor: pointer;\n  display: flex;\n  font-size: 0.9em;\n  font-weight: bold;\n  height: 50px;\n  justify-content: space-evenly;\n  position: fixed;\n  right: 3%;\n  transition: 0.4s ease;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n  width: 80px;\n}\n\n@media only screen and (max-width: 679px) {\n  ion-toolbar {\n    padding: 1em !important;\n    height: 90px;\n    max-height: 90px;\n  }\n  ion-toolbar .title {\n    font-size: 0.8em;\n  }\n\n  .create-post {\n    width: 35vw;\n  }\n  .create-post p {\n    margin-right: 5%;\n  }\n\n  .main-post-img {\n    border: 0;\n    max-height: 400px;\n  }\n\n  .container {\n    border-radius: 1em;\n    grid-template-columns: 1fr;\n    grid-template-rows: 1fr;\n    aspect-ratio: unset;\n  }\n  .container .content {\n    padding: 0.5em;\n  }\n  .container img {\n    max-width: 100vw;\n  }\n\n  .image {\n    filter: grayscale(0%);\n    transform: scale(1);\n    transition: 0.4s ease;\n  }\n\n  .main-post-img:hover .image {\n    border-radius: 1em;\n    filter: grayscale(0%);\n    transform: scale(1);\n    transition: 0.4s ease;\n  }\n\n  .end {\n    height: 30vh;\n    margin-bottom: 100px;\n  }\n\n  .scroll-top {\n    bottom: 110px;\n    right: 4%;\n  }\n\n  .post-text {\n    margin-top: 40vh;\n  }\n}\n\n@media only screen and (min-width: 580px) and (max-width: 767px) {\n  .create-post {\n    width: 30vw;\n  }\n  .create-post p {\n    margin-right: 5%;\n  }\n\n  .main-post-img {\n    background-color: none;\n    border: none;\n    max-height: 400px;\n  }\n\n  .image {\n    filter: grayscale(0%);\n    transform: scale(1);\n    transition: 0.4s ease;\n  }\n\n  .main-post-img:hover .image {\n    border-radius: 1em;\n    filter: grayscale(0%);\n    transform: scale(1);\n    transition: 0.4s ease;\n  }\n\n  .container {\n    grid-template-columns: 1fr 1fr;\n    grid-template-rows: 1fr 1fr;\n    aspect-ratio: unset;\n  }\n  .container .content {\n    padding: 0.5em;\n  }\n  .container img {\n    max-width: 100vw;\n  }\n\n  .post-text {\n    margin-top: 105%;\n  }\n}\n\n@media only screen and (min-width: 768px) and (max-width: 979px) {\n  .create-post {\n    width: 20vw;\n  }\n  .create-post p {\n    margin-right: 5%;\n  }\n\n  .container {\n    grid-template-columns: 1fr 1fr 1fr;\n    grid-template-rows: 1fr 1fr 1fr 1fr;\n    aspect-ratio: 0.65;\n  }\n\n  .post-text {\n    margin-top: 77%;\n  }\n}\n\n@media only screen and (min-width: 980px) and (max-width: 1023px) {\n  .create-post {\n    width: 20vw;\n  }\n  .create-post p {\n    margin-right: 5%;\n  }\n\n  .container {\n    grid-template-columns: 1fr 1fr 1fr 1fr;\n    grid-template-rows: 1fr 1fr 1fr 1fr;\n  }\n\n  .post-text {\n    margin-top: 65%;\n  }\n}\n\n@media only screen and (min-width: 1024px) and (max-width: 1199px) {\n  .container {\n    grid-template-columns: 1fr 1fr 1fr 1fr 1fr;\n    grid-template-rows: 1fr 1fr 1fr 1fr 1fr;\n  }\n\n  .post-text {\n    margin-top: 55%;\n  }\n}\n\n@media only screen and (min-width: 1200px) {\n  .container {\n    grid-template-columns: 1fr 1fr 1fr 1fr 1fr;\n    grid-template-rows: 1fr 1fr 1fr 1fr 1fr;\n  }\n\n  .post-text {\n    margin-top: 60%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxtYWluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7O0VBR0UsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLCtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBQUU7RUFDRSxnQkFBQTtBQUVKOztBQUVBO0VBQ0UsWUFBQTtBQUNGOztBQUNFO0VBQ0Usa0JBQUE7QUFDSjs7QUFHQTtFQUNFLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7QUFBRjs7QUFHQTtFQUNFLGFBQUE7RUFDQSwwQ0FBQTtFQUNBLHVDQUFBO0VBQ0EsZUFBQTtBQUFGOztBQUdBO0VBQ0UsNkNBQUE7RUFFQSw0QkFBQTtFQUNBLHNCQUFBO0VBQ0EscURBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxnQkFBQTtBQURGOztBQUdBO0VBQ0UsbUJBQUE7RUFDQSxxREFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFERjs7QUFHRTtFQUNFLDZCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7QUFESjs7QUFLSTtFQUNFLGFBQUE7RUFDQSxxQkFBQTtBQUhOOztBQVFFO0VBQ0Usb0JBQUE7S0FBQSxpQkFBQTtFQUNBLFdBQUE7QUFOSjs7QUFTRTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtBQVBKOztBQVNJO0VBQ0UsZ0JBQUE7QUFQTjs7QUFVSTtFQUNFLGNBQUE7RUFDQSxpQkFBQTtFQUNBLFNBQUE7QUFSTjs7QUFhQTtFQUNFLGdCQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0FBVkY7O0FBYUE7RUFDRSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLDJEQUFBO0FBVkY7O0FBYUE7RUFDRSxZQUFBO0FBVkY7O0FBYUE7RUFDRSxrQkFBQTtBQVZGOztBQWNBO0VBQ0UscURBQUE7RUFDQSw0QkFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFYRjs7QUFjQTtFQUNFLG1CQUFBO0VBQ0EsMkNBQUE7RUFDQSxXQUFBO0VBQ0EsdUNBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsNkJBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtFQUNBLHFCQUFBO0VBQ0EseUJBQUE7S0FBQSxzQkFBQTtVQUFBLGlCQUFBO0VBQ0EsV0FBQTtBQVhGOztBQWVBO0VBQ0U7SUFDRSx1QkFBQTtJQUNBLFlBQUE7SUFDQSxnQkFBQTtFQVpGO0VBYUU7SUFDRSxnQkFBQTtFQVhKOztFQWVBO0lBQ0UsV0FBQTtFQVpGO0VBYUU7SUFDRSxnQkFBQTtFQVhKOztFQWVBO0lBQ0UsU0FBQTtJQUNBLGlCQUFBO0VBWkY7O0VBZUE7SUFDRSxrQkFBQTtJQUNBLDBCQUFBO0lBQ0EsdUJBQUE7SUFFQSxtQkFBQTtFQWJGO0VBZUU7SUFDRSxjQUFBO0VBYko7RUFnQkU7SUFDRSxnQkFBQTtFQWRKOztFQWtCQTtJQUNFLHFCQUFBO0lBQ0EsbUJBQUE7SUFDQSxxQkFBQTtFQWZGOztFQWtCQTtJQUNFLGtCQUFBO0lBQ0EscUJBQUE7SUFDQSxtQkFBQTtJQUNBLHFCQUFBO0VBZkY7O0VBa0JBO0lBQ0UsWUFBQTtJQUNBLG9CQUFBO0VBZkY7O0VBa0JBO0lBQ0UsYUFBQTtJQUNBLFNBQUE7RUFmRjs7RUFrQkE7SUFDRSxnQkFBQTtFQWZGO0FBQ0Y7O0FBbUJBO0VBQ0U7SUFDRSxXQUFBO0VBakJGO0VBa0JFO0lBQ0UsZ0JBQUE7RUFoQko7O0VBb0JBO0lBQ0Usc0JBQUE7SUFDQSxZQUFBO0lBQ0EsaUJBQUE7RUFqQkY7O0VBb0JBO0lBQ0UscUJBQUE7SUFDQSxtQkFBQTtJQUNBLHFCQUFBO0VBakJGOztFQW9CQTtJQUNFLGtCQUFBO0lBQ0EscUJBQUE7SUFDQSxtQkFBQTtJQUNBLHFCQUFBO0VBakJGOztFQW9CQTtJQUNFLDhCQUFBO0lBQ0EsMkJBQUE7SUFDQSxtQkFBQTtFQWpCRjtFQW1CRTtJQUNFLGNBQUE7RUFqQko7RUFvQkU7SUFDRSxnQkFBQTtFQWxCSjs7RUFzQkE7SUFDRSxnQkFBQTtFQW5CRjtBQUNGOztBQXVCQTtFQUNFO0lBQ0UsV0FBQTtFQXJCRjtFQXNCRTtJQUNFLGdCQUFBO0VBcEJKOztFQXdCQTtJQUNFLGtDQUFBO0lBQ0EsbUNBQUE7SUFDQSxrQkFBQTtFQXJCRjs7RUF3QkE7SUFDRSxlQUFBO0VBckJGO0FBQ0Y7O0FBeUJBO0VBQ0U7SUFDRSxXQUFBO0VBdkJGO0VBd0JFO0lBQ0UsZ0JBQUE7RUF0Qko7O0VBMEJBO0lBQ0Usc0NBQUE7SUFDQSxtQ0FBQTtFQXZCRjs7RUEwQkE7SUFDRSxlQUFBO0VBdkJGO0FBQ0Y7O0FBMkJBO0VBQ0U7SUFDRSwwQ0FBQTtJQUNBLHVDQUFBO0VBekJGOztFQTRCQTtJQUNFLGVBQUE7RUF6QkY7QUFDRjs7QUE2QkE7RUFDRTtJQUNFLDBDQUFBO0lBQ0EsdUNBQUE7RUEzQkY7O0VBOEJBO0lBQ0UsZUFBQTtFQTNCRjtBQUNGIiwiZmlsZSI6Im1haW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRpdHRsZSxcbmlvbi1idXR0b24sXG5pb24taWNvbiB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkZXI7XG59XG5cbmlvbi1tZW51LWJ1dHRvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbi5jcmVhdGUtcG9zdCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgd2lkdGg6IDE1dnc7XG4gIHAge1xuICAgIG1hcmdpbi1yaWdodDogNSU7XG4gIH1cbn1cblxuaW9uLWJhZGdle1xuICBwYWRkaW5nOiA0cHg7XG5cbiAgaW9uLWljb257XG4gICAgZm9udC1zaXplOiAxMS42MnB4O1xuICB9XG59XG5cbi5vcHRpb25zLWJhZGdlIHtcbiAgcG9zaXRpb246IGFic29sdXRlICFpbXBvcnRhbnQ7XG4gIHJpZ2h0OiAwcHg7XG4gIHRvcDogMHB4O1xufVxuXG4uY29udGFpbmVyIHtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMWZyIDFmciAxZnIgMWZyO1xuICBncmlkLXRlbXBsYXRlLXJvd3M6IDFmciAxZnIgMWZyIDFmciAxZnI7XG4gIGFzcGVjdC1yYXRpbzogMTtcbn1cblxuLm1haW4tcG9zdC1pbWcge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvcik7XG4gIC8vYmFja2dyb3VuZC1pbWFnZTogVVJMKCcuLi8uLi9hc3NldHMvZGVmYXVsdC1wb3N0LnN2ZycpO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tdG9vbGJhci1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6IHdoaXRlO1xuICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcblxuLnNob3ctcG9zdCB7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi10b29sYmFyLWJhY2tncm91bmQtY29sb3IpO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGZvbnQtc2l6ZTogMS4zZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICB3aWR0aDogMTAwJTtcbiAgei1pbmRleDogMTA7XG5cbiAgLnNob3ctcG9zdC10aXRsZSB7XG4gICAgZm9udC1mYW1pbHk6ICdWaXNieSBSb3VuZCBDRic7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgb3BhY2l0eTogNjAlO1xuICAgIHRyYW5zaXRpb246IDAuNHMgZWFzZTtcbiAgfVxuXG4gICY6aG92ZXIge1xuICAgIC5zaG93LXBvc3QtdGl0bGUge1xuICAgICAgb3BhY2l0eTogMTAwJTtcbiAgICAgIHRyYW5zaXRpb246IDAuNHMgZWFzZTtcbiAgICB9XG4gIH1cbn1cblxuICBpbWcge1xuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG5cbiAgLmNvbnRlbnQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBwYWRkaW5nOiAxZW07XG5cbiAgICAub3B0aW9ucyB7XG4gICAgICBtYXJnaW4tcmlnaHQ6IDElO1xuICAgIH1cblxuICAgIGgxIHtcbiAgICAgIGZvbnQtc2l6ZTogMWVtO1xuICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICBtYXJnaW46IDA7XG4gICAgfVxuICB9XG59XG5cbi5pbWFnZSB7XG4gIGJvcmRlci1yYWRpdXM6IDA7XG4gIGZpbHRlcjogZ3JheXNjYWxlKDYwJSk7XG4gIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gIHRyYW5zaXRpb246IDAuNHMgZWFzZTtcbn1cblxuLm1haW4tcG9zdC1pbWc6aG92ZXIgLmltYWdlIHtcbiAgYm9yZGVyLXJhZGl1czogMWVtO1xuICBmaWx0ZXI6IGdyYXlzY2FsZSgwJSk7XG4gIHRyYW5zZm9ybTogc2NhbGUoMC45NSk7XG4gIHRyYW5zaXRpb246IDAuNHMgZWFzZTtcbiAgYm94LXNoYWRvdzogLTZweCAtNjhweCA3OXB4IC0zN3B4IHJnYmEoMCwwLDAsMC41OSkgaW5zZXQ7XG59XG5cbi5pbmZvcm1hdGlvbiB7XG4gIHdpZHRoOiAyMDBweDtcbn1cblxuLnBvc3QtdGV4dCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgLy9tYXJnaW4tdG9wOiAxMDAlICFpbXBvcnRhbnQ7XG59XG5cbi5lbmQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tdG9vbGJhci1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgY29sb3I6IHZhcigtLWlvbi10ZXh0LWNvbG9yKTtcbiAgZGlzcGxheTogZ3JpZDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMWVtO1xuICBwbGFjZS1jb250ZW50OiBjZW50ZXI7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgd2lkdGg6IDEwMHZ3O1xuICBoZWlnaHQ6IDIwdmg7XG59XG5cbi5zY3JvbGwtdG9wIHtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KTtcbiAgYm90dG9tOiA4dmg7XG4gIGNvbG9yOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXNpemU6IC45ZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBoZWlnaHQ6IDUwcHg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHJpZ2h0OiAzJTtcbiAgdHJhbnNpdGlvbjogMC40cyBlYXNlO1xuICB1c2VyLXNlbGVjdDogbm9uZTtcbiAgd2lkdGg6IDgwcHg7XG59XG5cbi8vIEZvciB0eXBpY2FsIG1vYmlsZSBkZXZpY2VzICh1c2UgNDc5cHgpLlxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA2NzlweCkge1xuICBpb24tdG9vbGJhciB7XG4gICAgcGFkZGluZzogMWVtICFpbXBvcnRhbnQ7XG4gICAgaGVpZ2h0OiA5MHB4O1xuICAgIG1heC1oZWlnaHQ6IDkwcHg7XG4gICAgLnRpdGxlIHtcbiAgICAgIGZvbnQtc2l6ZTogLjhlbTtcbiAgICB9XG4gIH1cblxuICAuY3JlYXRlLXBvc3Qge1xuICAgIHdpZHRoOiAzNXZ3O1xuICAgIHAge1xuICAgICAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgICB9XG4gIH1cblxuICAubWFpbi1wb3N0LWltZyB7XG4gICAgYm9yZGVyOiAwO1xuICAgIG1heC1oZWlnaHQ6IDQwMHB4O1xuICB9XG5cbiAgLmNvbnRhaW5lciB7XG4gICAgYm9yZGVyLXJhZGl1czogMWVtO1xuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyO1xuICAgIGdyaWQtdGVtcGxhdGUtcm93czogMWZyO1xuICAgIFxuICAgIGFzcGVjdC1yYXRpbzogdW5zZXQ7XG5cbiAgICAuY29udGVudCB7XG4gICAgICBwYWRkaW5nOiAwLjVlbTtcbiAgICB9XG5cbiAgICBpbWcge1xuICAgICAgbWF4LXdpZHRoOiAxMDB2dztcbiAgICB9XG4gIH1cblxuICAuaW1hZ2Uge1xuICAgIGZpbHRlcjogZ3JheXNjYWxlKDAlKTtcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xuICAgIHRyYW5zaXRpb246IDAuNHMgZWFzZTtcbiAgfVxuICBcbiAgLm1haW4tcG9zdC1pbWc6aG92ZXIgLmltYWdlIHtcbiAgICBib3JkZXItcmFkaXVzOiAxZW07XG4gICAgZmlsdGVyOiBncmF5c2NhbGUoMCUpO1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgdHJhbnNpdGlvbjogMC40cyBlYXNlO1xuICB9XG4gIFxuICAuZW5kIHtcbiAgICBoZWlnaHQ6IDMwdmg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTAwcHg7XG4gIH1cbiAgXG4gIC5zY3JvbGwtdG9wIHtcbiAgICBib3R0b206IDExMHB4O1xuICAgIHJpZ2h0OiA0JTtcbiAgfVxuXG4gIC5wb3N0LXRleHQge1xuICAgIG1hcmdpbi10b3A6IDQwdmg7XG4gIH1cbn1cbi8vIERlZmF1bHQgcG9zdHMgdmlldy4gVHdvIGRpdnMgcGVyIHJvdy5cbi8vIEZvciBtb2JpbGUgKGxhbmRzY2FwZSkuXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDU4MHB4KSBhbmQgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgLmNyZWF0ZS1wb3N0IHtcbiAgICB3aWR0aDogMzB2dztcbiAgICBwIHtcbiAgICAgIG1hcmdpbi1yaWdodDogNSU7XG4gICAgfVxuICB9XG5cbiAgLm1haW4tcG9zdC1pbWcge1xuICAgIGJhY2tncm91bmQtY29sb3I6IG5vbmU7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIG1heC1oZWlnaHQ6IDQwMHB4O1xuICB9XG5cbiAgLmltYWdlIHtcbiAgICBmaWx0ZXI6IGdyYXlzY2FsZSgwJSk7XG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICB0cmFuc2l0aW9uOiAwLjRzIGVhc2U7XG4gIH1cbiAgXG4gIC5tYWluLXBvc3QtaW1nOmhvdmVyIC5pbWFnZSB7XG4gICAgYm9yZGVyLXJhZGl1czogMWVtO1xuICAgIGZpbHRlcjogZ3JheXNjYWxlKDAlKTtcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xuICAgIHRyYW5zaXRpb246IDAuNHMgZWFzZTtcbiAgfVxuXG4gIC5jb250YWluZXIge1xuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIDFmcjtcbiAgICBncmlkLXRlbXBsYXRlLXJvd3M6IDFmciAxZnI7XG4gICAgYXNwZWN0LXJhdGlvOiB1bnNldDtcblxuICAgIC5jb250ZW50IHtcbiAgICAgIHBhZGRpbmc6IDAuNWVtO1xuICAgIH1cblxuICAgIGltZyB7XG4gICAgICBtYXgtd2lkdGg6IDEwMHZ3O1xuICAgIH1cbiAgfVxuXG4gIC5wb3N0LXRleHQge1xuICAgIG1hcmdpbi10b3A6IDEwNSU7XG4gIH1cbn1cblxuLy8gRm9yIHRhYmxldHNcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogNzY4cHgpIGFuZCAobWF4LXdpZHRoOiA5NzlweCkge1xuICAuY3JlYXRlLXBvc3Qge1xuICAgIHdpZHRoOiAyMHZ3O1xuICAgIHAge1xuICAgICAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgICB9XG4gIH1cblxuICAuY29udGFpbmVyIHtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyO1xuICAgIGdyaWQtdGVtcGxhdGUtcm93czogMWZyIDFmciAxZnIgMWZyO1xuICAgIGFzcGVjdC1yYXRpbzogMC42NTtcbiAgfVxuXG4gIC5wb3N0LXRleHQge1xuICAgIG1hcmdpbi10b3A6IDc3JTtcbiAgfVxufVxuXG4vLyBGb3Igc21hbGwgZGVza3RvcFxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOiA5ODBweCkgYW5kIChtYXgtd2lkdGg6IDEwMjNweCkge1xuICAuY3JlYXRlLXBvc3Qge1xuICAgIHdpZHRoOiAyMHZ3O1xuICAgIHAge1xuICAgICAgbWFyZ2luLXJpZ2h0OiA1JTtcbiAgICB9XG4gIH1cblxuICAuY29udGFpbmVyIHtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyIDFmcjtcbiAgICBncmlkLXRlbXBsYXRlLXJvd3M6IDFmciAxZnIgMWZyIDFmcjtcbiAgfVxuXG4gIC5wb3N0LXRleHQge1xuICAgIG1hcmdpbi10b3A6IDY1JTtcbiAgfVxufVxuXG4vLyBGb3IgdHlwaWNhbCBkZXNrdG9wXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDEwMjRweCkgYW5kIChtYXgtd2lkdGg6IDExOTlweCkge1xuICAuY29udGFpbmVyIHtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyIDFmciAxZnI7XG4gICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiAxZnIgMWZyIDFmciAxZnIgMWZyO1xuICB9XG5cbiAgLnBvc3QtdGV4dCB7XG4gICAgbWFyZ2luLXRvcDogNTUlO1xuICB9XG59XG5cbi8vIEZvciBsYXJnZSBkZXNrdG9wXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDEyMDBweCkge1xuICAuY29udGFpbmVyIHtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyIDFmciAxZnI7XG4gICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiAxZnIgMWZyIDFmciAxZnIgMWZyO1xuICB9XG5cbiAgLnBvc3QtdGV4dCB7XG4gICAgbWFyZ2luLXRvcDogNjAlO1xuICB9XG59XG4iXX0= */";
      /***/
    },

    /***/
    "QvMP":
    /*!***************************************************************************************!*\
      !*** ./src/app/components/notifications-preview/notifications-preview.component.scss ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function QvMP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJub3RpZmljYXRpb25zLXByZXZpZXcuY29tcG9uZW50LnNjc3MifQ== */";
      /***/
    },

    /***/
    "TIEH":
    /*!***************************************************!*\
      !*** ./src/app/pages/main/main-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: MainPageRoutingModule */

    /***/
    function TIEH(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MainPageRoutingModule", function () {
        return MainPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _main_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./main.page */
      "TQIn");
      /* harmony import */


      var _admins_admins_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../admins/admins.component */
      "VnJM");

      var routes = [{
        path: '',
        component: _main_page__WEBPACK_IMPORTED_MODULE_3__["MainPage"]
      }, {
        path: 'admins',
        component: _admins_admins_component__WEBPACK_IMPORTED_MODULE_4__["AdminsComponent"]
      }];

      var MainPageRoutingModule = function MainPageRoutingModule() {
        _classCallCheck(this, MainPageRoutingModule);
      };

      MainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], MainPageRoutingModule);
      /***/
    },

    /***/
    "TQIn":
    /*!*****************************************!*\
      !*** ./src/app/pages/main/main.page.ts ***!
      \*****************************************/

    /*! exports provided: MainPage */

    /***/
    function TQIn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MainPage", function () {
        return MainPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_main_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./main.page.html */
      "c9wX");
      /* harmony import */


      var _main_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./main.page.scss */
      "8rh1");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _components_notifications_preview_notifications_preview_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../components/notifications-preview/notifications-preview.component */
      "ifQo");
      /* harmony import */


      var _components_post_options_post_options_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../components/post-options/post-options.component */
      "/ie9");
      /* harmony import */


      var _new_post_new_post_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../new-post/new-post.page */
      "ccyQ");
      /* harmony import */


      var _services_post_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../services/post.service */
      "ENZJ");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");
      /* harmony import */


      var src_app_services_session_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! src/app/services/session.service */
      "IfdK");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @ionic/storage */
      "e8h1");
      /* harmony import */


      var src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! src/app/helpers/functions */
      "3crM");

      var MainPage = /*#__PURE__*/function () {
        function MainPage(document, activatedRoute, modalCtrl, popoverCtrl, toastCtrl, postServ, router, http, title, sessionServ, storage) {
          var _this2 = this;

          _classCallCheck(this, MainPage);

          this.document = document;
          this.activatedRoute = activatedRoute;
          this.modalCtrl = modalCtrl;
          this.popoverCtrl = popoverCtrl;
          this.toastCtrl = toastCtrl;
          this.postServ = postServ;
          this.router = router;
          this.http = http;
          this.title = title;
          this.sessionServ = sessionServ;
          this.storage = storage;
          this.posts = new Array();
          this.endOfThePage = false;
          this.isDown = false;
          this.newPosts = 0;
          this.activatedRoute.params.subscribe(function (_) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      this.title.setTitle('Anon Land');
                      this.category = this.activatedRoute.snapshot.paramMap.get('category');
                      _context3.next = 4;
                      return this.sessionServ.verifySession();

                    case 4:
                      _context3.next = 6;
                      return this.getPostsFeed();

                    case 6:
                      this.hideSavedPosts();
                      this.setSocketsHandler();

                    case 8:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          });
        }

        _createClass(MainPage, [{
          key: "getPostsFeed",
          value: function getPostsFeed() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var _this3 = this;

              var posts;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      if (!(!this.category || this.category === 'off')) {
                        _context4.next = 6;
                        break;
                      }

                      _context4.next = 3;
                      return this.postServ.getPostList();

                    case 3:
                      posts = _context4.sent;
                      _context4.next = 9;
                      break;

                    case 6:
                      _context4.next = 8;
                      return this.postServ.getPostListByCategory(this.category);

                    case 8:
                      posts = _context4.sent;

                    case 9:
                      this.posts = new Array();
                      posts.forEach(function (post) {
                        var postObj = post.data();
                        postObj.id = post.id;

                        _this3.posts.push(postObj);
                      });

                    case 11:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "setSocketsHandler",
          value: function setSocketsHandler() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var _this4 = this;

              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      this.postServ.setSocketsHandler(function () {
                        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this4, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                          var _this5 = this;

                          var header, toast, reloadPosts;
                          return regeneratorRuntime.wrap(function _callee5$(_context5) {
                            while (1) {
                              switch (_context5.prev = _context5.next) {
                                case 0:
                                  this.newPosts++;
                                  header = this.newPosts == 1 ? "Hay 1 nuevo post" : "Hay ".concat(this.newPosts, " nuevos post");

                                  if (!(this.newPostsToast == undefined)) {
                                    _context5.next = 13;
                                    break;
                                  }

                                  _context5.next = 5;
                                  return this.toastCtrl.create({
                                    header: header,
                                    duration: 600000,
                                    position: 'top',
                                    color: 'success'
                                  });

                                case 5:
                                  toast = _context5.sent;
                                  _context5.next = 8;
                                  return toast.present();

                                case 8:
                                  reloadPosts = function reloadPosts() {
                                    toast.dismiss();
                                    _this5.newPosts = 0;
                                    _this5.newPostsToast = undefined;

                                    _this5.getPostsFeed();
                                  };

                                  toast.onclick = reloadPosts;
                                  this.newPostsToast = toast;
                                  _context5.next = 14;
                                  break;

                                case 13:
                                  this.newPostsToast.header = header;

                                case 14:
                                case "end":
                                  return _context5.stop();
                              }
                            }
                          }, _callee5, this);
                        }));
                      });

                    case 1:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "openPost",
          value: function openPost(post) {
            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      (_a = this.newPostsToast) === null || _a === void 0 ? void 0 : _a.dismiss();
                      this.postServ.removeSocketsHandler();
                      this.router.navigate([post.category, post.id]);

                    case 3:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }, {
          key: "createPost",
          value: function createPost() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
              var _this6 = this;

              var modal, event, formData;
              return regeneratorRuntime.wrap(function _callee9$(_context9) {
                while (1) {
                  switch (_context9.prev = _context9.next) {
                    case 0:
                      _context9.next = 2;
                      return this.modalCtrl.create({
                        component: _new_post_new_post_page__WEBPACK_IMPORTED_MODULE_8__["NewPostPage"],
                        cssClass: 'create-new-post-modal'
                      });

                    case 2:
                      modal = _context9.sent;
                      _context9.next = 5;
                      return modal.present();

                    case 5:
                      _context9.next = 7;
                      return modal.onDidDismiss();

                    case 7:
                      event = _context9.sent;

                      if (!(event.data != null)) {
                        _context9.next = 21;
                        break;
                      }

                      this.postServ.removeSocketsHandler();
                      formData = new FormData();
                      formData.append('post-img-upload', event.data.img);
                      formData.append('category', event.data.category);
                      formData.append('title', event.data.title);
                      formData.append('body', event.data.body);
                      _context9.t0 = formData;
                      _context9.next = 18;
                      return this.sessionServ.getSession();

                    case 18:
                      _context9.t1 = _context9.sent;

                      _context9.t0.append.call(_context9.t0, 'opid', _context9.t1);

                      this.http.post(Object(src_app_helpers_functions__WEBPACK_IMPORTED_MODULE_15__["createUrl"])('create'), formData, {
                        responseType: 'text'
                      }).subscribe(function (_) {
                        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this6, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
                          return regeneratorRuntime.wrap(function _callee8$(_context8) {
                            while (1) {
                              switch (_context8.prev = _context8.next) {
                                case 0:
                                  _context8.next = 2;
                                  return this.getPostsFeed();

                                case 2:
                                  this.hideSavedPosts();
                                  this.setSocketsHandler();

                                case 4:
                                case "end":
                                  return _context8.stop();
                              }
                            }
                          }, _callee8, this);
                        }));
                      });

                    case 21:
                    case "end":
                      return _context9.stop();
                  }
                }
              }, _callee9, this);
            }));
          }
        }, {
          key: "showOptions",
          value: function showOptions($event, postId) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var popover;
              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      console.log($event);
                      console.log(postId);
                      $event.stopPropagation();
                      _context10.next = 5;
                      return this.popoverCtrl.create({
                        component: _components_post_options_post_options_component__WEBPACK_IMPORTED_MODULE_7__["PostOptionsComponent"],
                        event: $event,
                        componentProps: {
                          postId: postId
                        }
                      });

                    case 5:
                      popover = _context10.sent;
                      _context10.next = 8;
                      return popover.present();

                    case 8:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this);
            }));
          } // Iterate all IDs in hiddenPostId.

        }, {
          key: "hideSavedPosts",
          value: function hideSavedPosts() {
            var _this7 = this;

            this.storage.forEach(function (value, key) {
              if (key === 'hiddenPostId') {
                value.forEach(function (id) {
                  return _this7.toggleHide(id);
                });
              }
            });
          } // Display placard for show the post.

        }, {
          key: "toggleHide",
          value: function toggleHide(postId) {
            var _this8 = this;

            var post = document.querySelector("#post_".concat(postId));
            var postImg = document.querySelector("#post_".concat(postId, " + img"));
            post.style.display = 'flex';
            postImg.style.display = 'none'; // Delete the post id as value from 'hiddenPostId'.

            this.storage.get('hiddenPostId').then(function (id) {
              //if (!id || id.length === 0) { return null; } // Do nothing if is null.
              var toKeep = [];

              var _iterator = _createForOfIteratorHelper(id),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var i = _step.value;

                  if (i !== postId) {
                    toKeep.push(i);
                  }
                } // Finally return the new hidden comments list.

              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }

              _this8.storage.set('hiddenPostId', toKeep);
            });
          } // Show the post and pop its id.

        }, {
          key: "showPost",
          value: function showPost(postId) {
            var post = document.querySelector("#post_".concat(postId));
            var postImg = document.querySelector("#post_".concat(postId, " + img"));
            post.style.display = 'none';
            postImg.style.display = 'block';
          }
        }, {
          key: "openNotificationsPreview",
          value: function openNotificationsPreview($event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              var popover;
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      _context11.next = 2;
                      return this.popoverCtrl.create({
                        component: _components_notifications_preview_notifications_preview_component__WEBPACK_IMPORTED_MODULE_6__["NotificationsPreviewComponent"],
                        event: $event
                      });

                    case 2:
                      popover = _context11.sent;
                      _context11.next = 5;
                      return popover.present();

                    case 5:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this);
            }));
          }
        }, {
          key: "onScroll",
          value: function onScroll(e) {
            if (e.detail.scrollTop > 500) {
              this.isDown = true;
            } else if (e.detail.scrollTop < 500) {
              this.isDown = false;
            }
          }
        }, {
          key: "goToTop",
          value: function goToTop() {
            this.content.scrollToPoint(0, 0, 400);
          }
        }, {
          key: "loadEndOfThePage",
          value: function loadEndOfThePage() {
            this.endOfThePage = true;
          }
        }]);

        return MainPage;
      }();

      MainPage.ctorParameters = function () {
        return [{
          type: Document,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Inject"],
            args: [_angular_common__WEBPACK_IMPORTED_MODULE_13__["DOCUMENT"]]
          }]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _services_post_service__WEBPACK_IMPORTED_MODULE_9__["PostService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClient"]
        }, {
          type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["Title"]
        }, {
          type: src_app_services_session_service__WEBPACK_IMPORTED_MODULE_12__["SessionService"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_14__["Storage"]
        }];
      };

      MainPage.propDecorators = {
        content: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"],
          args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonContent"]]
        }]
      };
      MainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-main',
        template: _raw_loader_main_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_main_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], MainPage);
      /***/
    },

    /***/
    "VnJM":
    /*!**************************************************!*\
      !*** ./src/app/pages/admins/admins.component.ts ***!
      \**************************************************/

    /*! exports provided: AdminsComponent */

    /***/
    function VnJM(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AdminsComponent", function () {
        return AdminsComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_admins_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./admins.component.html */
      "WzDB");
      /* harmony import */


      var _admins_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./admins.component.scss */
      "YaFy");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/platform-browser */
      "jhN1");

      var AdminsComponent = /*#__PURE__*/function () {
        function AdminsComponent(title) {
          _classCallCheck(this, AdminsComponent);

          this.title = title;
        }

        _createClass(AdminsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.title.setTitle('Administración');
          }
        }]);

        return AdminsComponent;
      }();

      AdminsComponent.ctorParameters = function () {
        return [{
          type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["Title"]
        }];
      };

      AdminsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-admins',
        template: _raw_loader_admins_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_admins_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], AdminsComponent);
      /***/
    },

    /***/
    "WzDB":
    /*!******************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/admins/admins.component.html ***!
      \******************************************************************************************/

    /*! exports provided: default */

    /***/
    function WzDB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n\t<ion-toolbar>\n\t<p class=\"header-title\">Admins Cpanel</p>\n\t\t<ion-buttons slot=\"end\">\n\t\t\t<ion-button color=\"primary\" shape=\"round\">\n\t\t\t\t<ion-icon name=\"notifications\"></ion-icon>\n\t\t\t</ion-button>\n\t\t\t<ion-title>\n\t\t\t\t{{ moderator || 'Moderador' }}\n\t\t\t</ion-title>\n\t\t\t<ion-button class=\"exit\" color=\"primary\" fill=\"solid\">\n\t\t\t\t<p>Salir</p>\n\t\t\t\t<ion-icon name=\"exit\"></ion-icon> \n\t\t\t</ion-button>\n\t\t</ion-buttons>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content [scrollEvents]=\"true\" (ionScroll)=\"onScroll($event)\">\n\t<main class=\"moderation\">\n\t\t<div class=\"dashboard\">\n\t\t\t<section class=\"reports\">\n\t\t\t\t<p class=\"title\">Reportes</p>\n\t\t\t\t<!-- <div class=\"report-card\" *ngFor=\"let report of reports\"> -->\n\t\t\t\t<div class=\"report-card\">\n\t\t\t\t\t<div class=\"nicho\">\n\t\t\t\t\t\t<p>Nicho:</p>\n\t\t\t\t\t\t<!-- <p>{{ report.nicho || '/off/'}}</p> -->\n\t\t\t\t\t\t<span>'/off/'</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"report-description\">\n\t\t\t\t\t\t<p>Reporte de categoría incorrecta</p>\n\t\t\t\t\t\t<span>PostID: 2j28dn10dxh2ofcb18jf</span>\n\t\t\t\t\t\t<!-- <p>{{ report.description || 'Reporte de categoría incorrecta'}}</p>\n\t\t\t\t\t\t<p>{{ report.postId || '2j28dn10dxh2ofcb18jf'}} -->\n\t\t\t\t\t</div>\n\t\t\t\t\t<a [routerLink]=\"[category][id]\" class=\"navigate-to-post\">\n\t\t\t\t\t\t<ion-icon name=\"chevron-forward-outline\"></ion-icon>\n\t\t\t\t\t</a>\n\t\t\t\t</div>\n\t\t\t</section>\n\t\t\n\t\t\t<section class=\"log\">\n\t\t\t\t<div class=\"log-title\">\n\t\t\t\t\t<p class=\"title\">Log de acciones</p>\n\t\t\t\t\t<ion-chip color=\"medium\" class=\"time-filter\">\n\t\t\t\t\t\t<ion-label>Fecha</ion-label>\n\t\t\t\t\t\t<ion-icon name=\"swap-vertical\"></ion-icon>\n\t\t\t\t\t</ion-chip>\n\t\t\t\t</div>\n\t\t\t\t<!-- <div class=\"log-card\" *ngFor=\"let action of actions\"> -->\n\t\t\t\t<div class=\"log-card\">\n\t\t\t\t\t<!-- <p>{{ action.moderator }}:</p>\n\t\t\t\t\t<p>{{ action.description }}</p> -->\n\t\t\t\t\t<p class=\"action-title\">Hizo esto:</p>\n\t\t\t\t\t<p class=\"action-detail\">Tal cosa</p>\n\t\t\t\t\t<div class=\"log-details\">\n\t\t\t\t\t\t<!-- <p>{{ action.postId }}</p>\n\t\t\t\t\t\t<p>{{ action.date }}</p> -->\n\t\t\t\t\t\t<div class=\"log-post-id log-detail-label\">\n\t\t\t\t\t\t\t<p>PostID:</p>\n\t\t\t\t\t\t\t<span>2j28dn10dxh2ofcb18jf</span>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"log-date log-detail-label\">\n\t\t\t\t\t\t\t<p>Fecha:</p>\n\t\t\t\t\t\t\t<span>24/01/2021 23:59</span>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</section>\n\t\t</div>\n\n\t\t<div class=\"moderators\">\n\t\t\t<p class=\"title\">Moderadores</p>\n\t\t\t<div class=\"mod-list\">\n\t\t\t\t<!-- <div class=\"mod\" *ngFor=\"let mod of mods\"> -->\n\t\t\t\t<div class=\"mod\">\n\t\t\t\t\t<img src=\"../../assets/mod/mod-1.svg\" alt=\"\">\n\t\t\t\t\t<div class=\"mod-details\">\n\t\t\t\t\t\t<!-- <div class=\"mod-name\">{{ mod.name || 'Moderator 1'}}</div>\n\t\t\t\t\t\t<div class=\"mod-status\">{{ mod.status || 'Active'}}</div> -->\n\t\t\t\t\t\t<div class=\"mod-name\">'Moderator 1'</div>\n\t\t\t\t\t\t<div class=\"mod-status\">'Active'</div>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</main>\n</ion-content>\n\n";
      /***/
    },

    /***/
    "Xhlt":
    /*!*****************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/notifications-preview/notifications-preview.component.html ***!
      \*****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Xhlt(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"ion-text-center\">\n    <p>Próximamente..</p>\n</div>";
      /***/
    },

    /***/
    "YaFy":
    /*!****************************************************!*\
      !*** ./src/app/pages/admins/admins.component.scss ***!
      \****************************************************/

    /*! exports provided: default */

    /***/
    function YaFy(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header {\n  padding: 2em;\n  border: none !important;\n  box-shadow: none !important;\n}\nion-header .header-title {\n  font-size: 2em;\n  font-weight: bold;\n}\nion-header ion-button {\n  margin: 0 5% 0 5% !important;\n}\nion-header ion-button:last-child {\n  width: 150px;\n}\n.moderation {\n  -moz-column-gap: 1em;\n       column-gap: 1em;\n  display: grid;\n  grid-template-columns: 3fr 1fr;\n  margin: 1.5em;\n}\n.dashboard {\n  background-color: var(--ion-toolbar-background-color);\n  -moz-column-gap: 1em;\n       column-gap: 1em;\n  border-radius: 1em;\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  padding: 1em;\n}\n.title {\n  font-size: 1.3em;\n  font-weight: bold;\n  margin: 0;\n}\n.report-card {\n  background-color: var(--ion-background-color);\n  cursor: pointer;\n  border-radius: 1em;\n  display: flex;\n  margin: 1em 0.5em 0.5em 0.5em;\n}\n.report-card .nicho {\n  border-radius: 1em 0 0 1em;\n  background-color: var(--ion-item-background-color);\n  font-size: 0.8em;\n  font-weight: bold;\n  padding: 1em;\n}\n.report-card .nicho span {\n  opacity: 70%;\n}\n.report-card .report-description {\n  font-weight: bold;\n  margin-left: 3%;\n  margin-bottom: 3%;\n  width: 100%;\n}\n.report-card .report-description span {\n  font-size: 0.8em;\n  opacity: 50%;\n  margin-bottom: 0.1em;\n}\n.report-card .navigate-to-post {\n  align-items: center;\n  display: flex;\n  font-size: 2em;\n  justify-content: center;\n}\n.log .log-title {\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n}\n.log .log-title .time-filter {\n  filter: brightness(1.5);\n  font-weight: bold;\n  margin: 0;\n  max-height: 25px;\n  padding: 0.8em;\n  -webkit-user-select: none;\n     -moz-user-select: none;\n          user-select: none;\n}\n.log .log-card {\n  background-color: var(--ion-background-color);\n  cursor: pointer;\n  border-radius: 1em;\n  display: flex;\n  flex-direction: column;\n  margin: 1em 0.5em 0.5em 0.5em;\n  padding: 1em;\n}\n.log .log-card .action-title {\n  font-weight: bold;\n  margin: 0;\n}\n.log .log-card .action-detail {\n  font-weight: 500;\n  margin: 0 0 5% 0;\n  opacity: 70%;\n  padding: 0.5em;\n}\n.log .log-card .log-details {\n  display: flex;\n  justify-content: space-between;\n  flex-direction: row;\n  font-size: 0.8em;\n  font-weight: bold;\n}\n.log .log-card .log-details span {\n  opacity: 70%;\n}\n.log .log-card .log-details .log-detail-label {\n  align-items: left;\n  display: flex;\n  flex-direction: column;\n  justify-content: none;\n}\n.log .log-card .log-details .log-detail-label p {\n  margin: 0;\n}\n.moderators {\n  margin-left: 5%;\n}\n.moderators .mod-list {\n  margin: 1em 0.5em 0.5em 0.5em;\n}\n.moderators .mod-list .mod {\n  display: flex;\n  align-items: center;\n}\n.moderators .mod-list .mod img {\n  border-radius: 50%;\n  width: 60px;\n}\n.moderators .mod-list .mod .mod-details {\n  align-items: center;\n  display: flex;\n  flex-direction: column;\n  font-weight: bold;\n  margin-left: 1em;\n}\n.moderators .mod-list .mod .mod-details .mod-name {\n  opacity: 80%;\n}\n.moderators .mod-list .mod .mod-details .mod-status {\n  font-weight: 500;\n  color: var(--ion-color-success);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxhZG1pbnMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSwyQkFBQTtBQUNKO0FBQ0k7RUFDSSxjQUFBO0VBQ0EsaUJBQUE7QUFDUjtBQUVJO0VBQ0ksNEJBQUE7QUFBUjtBQUVRO0VBQ0ksWUFBQTtBQUFaO0FBS0E7RUFDSSxvQkFBQTtPQUFBLGVBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxhQUFBO0FBRko7QUFLQTtFQUNJLHFEQUFBO0VBQ0Esb0JBQUE7T0FBQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0FBRko7QUFLQTtFQUNJLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxTQUFBO0FBRko7QUFLQTtFQUNJLDZDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0FBRko7QUFJSTtFQUNJLDBCQUFBO0VBQ0Esa0RBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtBQUZSO0FBSVE7RUFDSSxZQUFBO0FBRlo7QUFNSTtFQUNJLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQUpSO0FBTVE7RUFDSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtBQUpaO0FBUUk7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUFOUjtBQVdJO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7QUFSUjtBQVVRO0VBQ0ksdUJBQUE7RUFDQSxpQkFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtLQUFBLHNCQUFBO1VBQUEsaUJBQUE7QUFSWjtBQVlJO0VBQ0ksNkNBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSw2QkFBQTtFQUNBLFlBQUE7QUFWUjtBQVlRO0VBQ0ksaUJBQUE7RUFDQSxTQUFBO0FBVlo7QUFhUTtFQUNJLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtBQVhaO0FBY1E7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFaWjtBQWNZO0VBQ0ksWUFBQTtBQVpoQjtBQWVZO0VBQ0ksaUJBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtBQWJoQjtBQWVnQjtFQUNJLFNBQUE7QUFicEI7QUFvQkE7RUFDSSxlQUFBO0FBakJKO0FBa0JJO0VBQ0ksNkJBQUE7QUFoQlI7QUFrQlE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUFoQlo7QUFrQlk7RUFDSSxrQkFBQTtFQUNBLFdBQUE7QUFoQmhCO0FBbUJZO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBakJoQjtBQW1CZ0I7RUFDSSxZQUFBO0FBakJwQjtBQW9CZ0I7RUFDSSxnQkFBQTtFQUNBLCtCQUFBO0FBbEJwQiIsImZpbGUiOiJhZG1pbnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcbiAgICBwYWRkaW5nOiAyZW07XG4gICAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XG4gICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuXG4gICAgLmhlYWRlci10aXRsZSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMmVtO1xuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICB9XG5cbiAgICBpb24tYnV0dG9uIHtcbiAgICAgICAgbWFyZ2luOiAwIDUlIDAgNSUgIWltcG9ydGFudDtcblxuICAgICAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubW9kZXJhdGlvbiB7XG4gICAgY29sdW1uLWdhcDogMWVtO1xuICAgIGRpc3BsYXk6IGdyaWQ7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAzZnIgMWZyO1xuICAgIG1hcmdpbjogMS41ZW07XG59XG5cbi5kYXNoYm9hcmQge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi10b29sYmFyLWJhY2tncm91bmQtY29sb3IpO1xuICAgIGNvbHVtbi1nYXA6IDFlbTtcbiAgICBib3JkZXItcmFkaXVzOiAxZW07XG4gICAgZGlzcGxheTogZ3JpZDtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnI7XG4gICAgcGFkZGluZzogMWVtO1xufVxuXG4udGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMS4zZW07XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgbWFyZ2luOiAwO1xufVxuXG4ucmVwb3J0LWNhcmQge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogMWVtO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luOiAxZW0gMC41ZW0gMC41ZW0gMC41ZW07XG5cbiAgICAubmljaG8ge1xuICAgICAgICBib3JkZXItcmFkaXVzOiAxZW0gMCAwIDFlbTtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWl0ZW0tYmFja2dyb3VuZC1jb2xvcik7XG4gICAgICAgIGZvbnQtc2l6ZTogMC44ZW07XG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICBwYWRkaW5nOiAxZW07XG5cbiAgICAgICAgc3BhbiB7XG4gICAgICAgICAgICBvcGFjaXR5OiA3MCU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAucmVwb3J0LWRlc2NyaXB0aW9uIHtcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAzJTtcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMyU7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuXG4gICAgICAgIHNwYW4ge1xuICAgICAgICAgICAgZm9udC1zaXplOiAwLjhlbTtcbiAgICAgICAgICAgIG9wYWNpdHk6IDUwJTtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDAuMWVtO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLm5hdmlnYXRlLXRvLXBvc3Qge1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmb250LXNpemU6IDJlbTtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgfVxufVxuXG4ubG9nIHtcbiAgICAubG9nLXRpdGxlIHtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG4gICAgICAgIC50aW1lLWZpbHRlciB7XG4gICAgICAgICAgICBmaWx0ZXI6IGJyaWdodG5lc3MoMS41KTtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgICAgbWF4LWhlaWdodDogMjVweDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAuOGVtO1xuICAgICAgICAgICAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubG9nLWNhcmQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvcik7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMWVtO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICBtYXJnaW46IDFlbSAwLjVlbSAwLjVlbSAwLjVlbTtcbiAgICAgICAgcGFkZGluZzogMWVtO1xuXG4gICAgICAgIC5hY3Rpb24tdGl0bGUge1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgIH1cblxuICAgICAgICAuYWN0aW9uLWRldGFpbCB7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgbWFyZ2luOiAwIDAgNSUgMDtcbiAgICAgICAgICAgIG9wYWNpdHk6IDcwJTtcbiAgICAgICAgICAgIHBhZGRpbmc6IDAuNWVtO1xuICAgICAgICB9XG5cbiAgICAgICAgLmxvZy1kZXRhaWxzIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgICAgICAgZm9udC1zaXplOiAwLjhlbTtcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuXG4gICAgICAgICAgICBzcGFuIHtcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiA3MCU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5sb2ctZGV0YWlsLWxhYmVsIHtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogbGVmdDtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBub25lO1xuXG4gICAgICAgICAgICAgICAgcCB7XG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5tb2RlcmF0b3JzIHtcbiAgICBtYXJnaW4tbGVmdDogNSU7XG4gICAgLm1vZC1saXN0IHtcbiAgICAgICAgbWFyZ2luOiAxZW0gMC41ZW0gMC41ZW0gMC41ZW07XG5cbiAgICAgICAgLm1vZCB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgICAgICAgd2lkdGg6IDYwcHg7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC5tb2QtZGV0YWlscyB7XG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDFlbTtcblxuICAgICAgICAgICAgICAgIC5tb2QtbmFtZSB7XG4gICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDgwJTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAubW9kLXN0YXR1cyB7XG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuIl19 */";
      /***/
    },

    /***/
    "aOgp":
    /*!*****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/new-post/new-post.page.html ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function aOgp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar class=\"new-vox-title\">\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"danger\" fill=\"solid\" (click)=\"cancelCreate()\">\n        ANULAR\n      </ion-button>\n      <ion-button color=\"tertiary\" fill=\"solid\" [disabled]=\"!newPostForm.valid\" (click)=\"createNewPost()\">\n        PUBLICAR\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Nuevo post</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<!-- <ion-content>\n  <ion-list> -->\n<form class=\"new-post-form\" [formGroup]=\"newPostForm\">\n  <div class=\"new-post-img\">\n    <input id=\"upload-img\" type=\"file\" name=\"post-img-upload\" accept=\"image/*\" (change)=\"onSelectFile($event)\" />\n    <label for=\"upload-img\" id=\"file-drag\">\n      <img [src]=\"newPostForm.value.imgPreview\" alt=\"\">\n      <ion-item *ngIf=\"showUploadImgText\" lines=\"none\">\n        <ion-icon color=\"bright\" slot=\"start\" name=\"cloud-upload\"></ion-icon>\n        <ion-label>Cargar Imágen.<br>\n          <p>Vacio. Miniatura por defecto.</p>\n        </ion-label> <br>\n      </ion-item>\n    </label>\n  </div>\n  <div class=\"new-post-content\">\n    <div class=\"new-post-category\">\n      <ion-label>Nicho</ion-label>\n      <ion-select placeholder=\"General\" okText=\"Elegir\" cancelText=\"Cancelar\" name=\"category\"\n        formControlName=\"category\">\n        <ion-select-option value=\"off\">General</ion-select-option>\n        <ion-select-option value=\"prg\">Preguntas</ion-select-option>\n        <ion-select-option value=\"mus\">Música</ion-select-option>\n        <ion-select-option value=\"cin\">Cine</ion-select-option>\n        <ion-select-option value=\"sci\">Ciencia</ion-select-option>\n        <ion-select-option value=\"his\">Historia</ion-select-option>\n        <ion-select-option value=\"pol\">Política</ion-select-option>\n        <ion-select-option value=\"art\">Arte</ion-select-option>\n        <ion-select-option value=\"nor\">Normie</ion-select-option>\n        <ion-select-option value=\"anm\">Anime</ion-select-option>\n        <ion-select-option value=\"uff\">Random</ion-select-option>\n      </ion-select>\n    </div>\n    <div class=\"new-post-content-text\">\n      <ion-label *ngIf=\"newPostForm.get('title').errors && newPostForm.get('title').hasError('required') && newPostForm.get('title').touched\" color=\"danger\">\n        El título es obligatorio\n      </ion-label>\n      <ion-label *ngIf=\"newPostForm.get('title').errors && newPostForm.get('title').hasError('maxlength') && newPostForm.get('title').touched\" color=\"danger\">\n        El título no puede exceder los 50 carácteres\n      </ion-label>\n\n      <ion-item>\n        <ion-input name=\"title\" formControlName=\"title\" placeholder=\"Título\"></ion-input>\n      </ion-item>\n    </div>\n    <div class=\"new-post-content-text\">\n      <ion-label *ngIf=\"newPostForm.get('body').errors && newPostForm.get('body').hasError('maxlength') && newPostForm.get('body').touched\" color=\"danger\">\n        El contenido no puede exceder los 1500 carácteres\n      </ion-label>\n      <ion-item class=\"content-text-last\">\n        <ion-textarea rows=\"11\" cols=\"30\" placeholder=\"Contenido\" name=\"body\" formControlName=\"body\">\n        </ion-textarea>\n      </ion-item>\n    </div>\n  </div>\n\n\n</form>\n<!-- </ion-list>\n</ion-content> -->";
      /***/
    },

    /***/
    "c9wX":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/main/main.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function c9wX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n\n    <p class=\"title\">{{ category | fullCategory }}</p>\n\n    <ion-buttons slot=\"end\">\n      <ion-button color=\"primary\" shape=\"round\" (click)=\"openNotificationsPreview($event)\">\n        <ion-icon name=\"notifications\"></ion-icon>\n      </ion-button>\n      <ion-button class=\"create-post\" color=\"primary\" fill=\"solid\" (click)=\"createPost()\">\n        <p>Nuevo post</p>\n        <ion-icon name=\"duplicate\"></ion-icon> \n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\" [scrollEvents]=\"true\" (ionScroll)=\"onScroll($event)\">\n  <div class=\"container\">\n    <div class=\"main-post-img\" *ngFor=\"let post of posts\">\n      <div class=\"show-post\" id=\"post_{{ post.id }}\" (click)=\"showPost(post.id)\">\n        <ion-icon  class=\"show-post-title\" slot=\"start\" ios=\"eye-off-outline\" md=\"eye-off-sharp\"></ion-icon>\n        <ion-label class=\"show-post-title\">   Click Para mostrar</ion-label>\n      </div>\n      <img [src]=\"post.imgPath || '../../assets/default-post.svg'\" [alt]=\"post.title\"\n        (click)=\"openPost(post)\"\n        (load)=\"loadEndOfThePage()\"\n        class=\"image\">\n      <div class=\"content\">\n        <div class=\"information\">\n          <ion-badge color=\"medium\" class=\"options\" (click)=\"showOptions($event, post.id)\">\n            <ion-icon name=\"ellipsis-vertical\"></ion-icon>\n          </ion-badge>\n          <ion-badge color=\"primary\">{{post.category | uppercase}}</ion-badge>\n        </div>\n        <div class=\"post-text\">\n          <h1>{{post.title}}</h1>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div *ngIf=\"endOfThePage\" class=\"end\">\n    <p>\n      Fin de los posts, Anon. <br>\n      Pero aún podés hacer el tuyo...\n    </p>\n  </div>\n</ion-content>\n\n<div class=\"scroll-top\" (click)=\"goToTop()\" *ngIf=\"isDown\" style=\"border-radius: 5px\">\n  <ion-icon name=\"chevron-up\" color=\"dark\"></ion-icon>\n  <span class=\"scroll-title\" style=\"color: black\">Arriba</span>\n</div>\n";
      /***/
    },

    /***/
    "ccyQ":
    /*!*************************************************!*\
      !*** ./src/app/pages/new-post/new-post.page.ts ***!
      \*************************************************/

    /*! exports provided: NewPostPage */

    /***/
    function ccyQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NewPostPage", function () {
        return NewPostPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_new_post_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./new-post.page.html */
      "aOgp");
      /* harmony import */


      var _new_post_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./new-post.page.scss */
      "qJAh");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var NewPostPage = /*#__PURE__*/function () {
        function NewPostPage(modalCtrl, http) {
          _classCallCheck(this, NewPostPage);

          this.modalCtrl = modalCtrl;
          this.http = http;
          this.showUploadImgText = true;
          this.newPostForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormGroup"]({
            category: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"]('off', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required),
            img: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](''),
            imgPreview: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](''),
            title: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](undefined, [_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].minLength(1), _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].maxLength(50)]),
            body: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormControl"](undefined, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].maxLength(1500))
          });
        }

        _createClass(NewPostPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "cancelCreate",
          value: function cancelCreate() {
            this.modalCtrl.dismiss();
          }
        }, {
          key: "createNewPost",
          value: function createNewPost() {
            this.modalCtrl.dismiss(this.newPostForm.value);
          }
        }, {
          key: "onSelectFile",
          value: function onSelectFile(preview) {
            var _this9 = this;

            if (preview.target.files && preview.target.files[0]) {
              var reader = new FileReader();
              this.showUploadImgText = false;
              reader.readAsDataURL(preview.target.files[0]); // read file as data url

              reader.onload = function (event) {
                _this9.newPostForm.patchValue({
                  img: preview.target.files[0]
                });

                _this9.newPostForm.patchValue({
                  imgPreview: event.target.result
                });
              };
            }
          }
        }]);

        return NewPostPage;
      }();

      NewPostPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
        }];
      };

      NewPostPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-new-post',
        template: _raw_loader_new_post_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_new_post_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], NewPostPage);
      /***/
    },

    /***/
    "ifQo":
    /*!*************************************************************************************!*\
      !*** ./src/app/components/notifications-preview/notifications-preview.component.ts ***!
      \*************************************************************************************/

    /*! exports provided: NotificationsPreviewComponent */

    /***/
    function ifQo(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NotificationsPreviewComponent", function () {
        return NotificationsPreviewComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_notifications_preview_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./notifications-preview.component.html */
      "Xhlt");
      /* harmony import */


      var _notifications_preview_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./notifications-preview.component.scss */
      "QvMP");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var NotificationsPreviewComponent = /*#__PURE__*/function () {
        function NotificationsPreviewComponent() {
          _classCallCheck(this, NotificationsPreviewComponent);
        }

        _createClass(NotificationsPreviewComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return NotificationsPreviewComponent;
      }();

      NotificationsPreviewComponent.ctorParameters = function () {
        return [];
      };

      NotificationsPreviewComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-notifications-preview',
        template: _raw_loader_notifications_preview_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_notifications_preview_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], NotificationsPreviewComponent);
      /***/
    },

    /***/
    "lzmV":
    /*!*********************************************!*\
      !*** ./src/app/pipes/full-category.pipe.ts ***!
      \*********************************************/

    /*! exports provided: FullCategoryPipe */

    /***/
    function lzmV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FullCategoryPipe", function () {
        return FullCategoryPipe;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var FullCategoryPipe = /*#__PURE__*/function () {
        function FullCategoryPipe() {
          _classCallCheck(this, FullCategoryPipe);
        }

        _createClass(FullCategoryPipe, [{
          key: "transform",
          value: function transform(value) {
            switch (value) {
              case 'prg':
                return '/prg/ ~ Preguntas';

              case 'mus':
                return '/mus/ ~ Música';

              case 'cin':
                return '/cin/ ~ Cine';

              case 'sci':
                return '/sci/ ~ Ciencia y Tecnonlogía';

              case 'his':
                return '/his/ ~ Historia';

              case 'art':
                return '/art/ ~ Arte';

              case 'pol':
                return '/pol/ ~ Política';

              case 'nor':
                return '/nor/ ~ Normie';

              case 'uff':
                return '/uff/ ~ Random';

              case 'a':
                return '/anm/ ~ Anime';

              default:
                return '/off/ ~ General';
            }
          }
        }]);

        return FullCategoryPipe;
      }();

      FullCategoryPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'fullCategory'
      })], FullCategoryPipe);
      /***/
    },

    /***/
    "p96T":
    /*!*********************************************************************!*\
      !*** ./src/app/components/post-options/post-options.component.scss ***!
      \*********************************************************************/

    /*! exports provided: default */

    /***/
    function p96T(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-item {\n  cursor: pointer;\n}\nion-item ion-icon {\n  color: var(--ion-color-medium);\n  margin-right: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwb3N0LW9wdGlvbnMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0FBQ0o7QUFBUTtFQUNJLDhCQUFBO0VBQ0Esa0JBQUE7QUFFWiIsImZpbGUiOiJwb3N0LW9wdGlvbnMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAgICAgICB9XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "qJAh":
    /*!***************************************************!*\
      !*** ./src/app/pages/new-post/new-post.page.scss ***!
      \***************************************************/

    /*! exports provided: default */

    /***/
    function qJAh(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".new-vox-title {\n  --background: var(--ion-color-primary-shade);\n  font-weight: bolder;\n  padding: 0 2%;\n}\n.new-vox-title ion-toolbar {\n  --background: var(--ion-color-primary-shade);\n  --color: #FEFFFC;\n}\n.new-vox-title ion-button {\n  width: 80px;\n  height: 40px;\n  font-weight: bolder;\n}\n.new-vox-title ion-button:last-child {\n  width: 150px;\n}\n.new-vox-title .new-post-publish {\n  width: 150px;\n}\n.new-post-form {\n  background-color: var(--ion-color-dark);\n  color: #FEFFFC;\n  display: grid;\n  grid-auto-flow: dense;\n  grid-template-columns: 2fr 2fr;\n  height: 100%;\n  padding: 4%;\n}\n.new-post-img {\n  align-items: center;\n  background-color: var(--ion-color-primary-shade);\n  border-radius: 2px;\n  color: #FEFFFC;\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  justify-content: center;\n  width: 100%;\n}\n.new-post-img input {\n  display: none;\n}\n.new-post-img label {\n  align-items: center;\n  display: flex;\n  color: #FEFFFC;\n  cursor: pointer;\n  flex-direction: column;\n  height: 100%;\n  justify-content: center;\n  width: 100%;\n}\n.new-post-img label img {\n  max-height: 380px;\n  max-width: 100%;\n}\n.new-post-img label ion-item {\n  --background: none;\n  --color: #FEFFFC;\n}\n.new-post-img label p {\n  color: var(--ion-color-primary-tint);\n  font-size: 0.8em;\n  margin: 0;\n}\n.new-post-content {\n  background-color: var(--ion-color-dark);\n  display: grid;\n  flex-direction: column;\n  font-weight: bold;\n  grid-template-rows: auto 1fr 4fr;\n}\n.new-post-content .new-post-category {\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n  padding: 4%;\n}\n.new-post-content .new-post-category ion-select {\n  background-color: var(--ion-color-secondary-shade);\n  border-radius: 2px;\n  padding: 2%;\n  width: 40%;\n}\n.new-post-content .new-post-content-text {\n  background-color: none;\n  flex-direction: column;\n  padding: 0 4% 0 4%;\n}\n.new-post-content ion-item {\n  --background: var(--ion-color-primary-shade);\n  --color: #FEFFFC;\n  display: flex;\n  font-weight: 400;\n}\n.new-post-content .content-text-last {\n  height: 100%;\n}\n@media only screen and (max-width: 679px) {\n  .new-post-form {\n    grid-template-columns: none;\n    width: 100vw;\n  }\n\n  .new-vox-title {\n    padding: 2% 4% 4% 4%;\n  }\n  .new-vox-title ion-button {\n    width: 80px;\n    height: 40px;\n  }\n  .new-vox-title ion-button:last-child {\n    width: 150px;\n  }\n\n  .new-post-content {\n    grid-template-rows: none;\n    row-gap: 4%;\n  }\n  .new-post-content .new-post-content-text {\n    padding: 0;\n  }\n\n  .new-post-category {\n    padding: 2% !important;\n  }\n\n  .new-post-img label img {\n    max-height: 35vh;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxuZXctcG9zdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSw0Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtBQUNKO0FBQUk7RUFDSSw0Q0FBQTtFQUNBLGdCQUFBO0FBRVI7QUFBSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFFUjtBQURRO0VBQ0ksWUFBQTtBQUdaO0FBQUk7RUFDSSxZQUFBO0FBRVI7QUFFQTtFQUNJLHVDQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtFQUNBLDhCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFDSjtBQUVBO0VBQ0ksbUJBQUE7RUFDQSxnREFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtBQUVSO0FBQUk7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtBQUVSO0FBRFE7RUFDSSxpQkFBQTtFQUNBLGVBQUE7QUFHWjtBQURRO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBQUdaO0FBRFE7RUFDSSxvQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBQUdaO0FBRUE7RUFDSSx1Q0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0NBQUE7QUFDSjtBQUFJO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxXQUFBO0FBRVI7QUFEUTtFQUNJLGtEQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtBQUdaO0FBQUk7RUFDSSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUFFUjtBQUNJO0VBQ0ksNENBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtBQUNSO0FBRUk7RUFDSSxZQUFBO0FBQVI7QUFLQTtFQUNJO0lBQ0ksMkJBQUE7SUFDQSxZQUFBO0VBRk47O0VBS0U7SUFDSSxvQkFBQTtFQUZOO0VBR007SUFDSSxXQUFBO0lBQ0EsWUFBQTtFQURWO0VBRVU7SUFDSSxZQUFBO0VBQWQ7O0VBS0U7SUFDSSx3QkFBQTtJQUNBLFdBQUE7RUFGTjtFQUdNO0lBQ0ksVUFBQTtFQURWOztFQUtFO0lBQ0ksc0JBQUE7RUFGTjs7RUFNTTtJQUNJLGdCQUFBO0VBSFY7QUFDRiIsImZpbGUiOiJuZXctcG9zdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubmV3LXZveC10aXRsZSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1zaGFkZSk7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbiAgICBwYWRkaW5nOiAwIDIlO1xuICAgIGlvbi10b29sYmFyIHtcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1zaGFkZSk7XG4gICAgICAgIC0tY29sb3I6ICNGRUZGRkM7XG4gICAgfVxuICAgIGlvbi1idXR0b24ge1xuICAgICAgICB3aWR0aDogODBweDtcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICBmb250LXdlaWdodDogYm9sZGVyO1xuICAgICAgICAmOmxhc3QtY2hpbGQge1xuICAgICAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgICB9XG4gICAgfVxuICAgIC5uZXctcG9zdC1wdWJsaXNoIHtcbiAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgIH1cbn1cblxuLm5ldy1wb3N0LWZvcm0ge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgICBjb2xvcjogI0ZFRkZGQztcbiAgICBkaXNwbGF5OiBncmlkO1xuICAgIGdyaWQtYXV0by1mbG93OiBkZW5zZTtcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDJmciAyZnI7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIHBhZGRpbmc6IDQlO1xufVxuXG4ubmV3LXBvc3QtaW1nIHtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXNoYWRlKTtcbiAgICBib3JkZXItcmFkaXVzOiAycHg7XG4gICAgY29sb3I6ICNGRUZGRkM7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGhlaWdodDogMTAwJTtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBpbnB1dCB7XG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxuICAgIGxhYmVsIHtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgY29sb3I6ICNGRUZGRkM7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGltZyB7XG4gICAgICAgICAgICBtYXgtaGVpZ2h0OiAzODBweDtcbiAgICAgICAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgICAgICAgfVxuICAgICAgICBpb24taXRlbSB7XG4gICAgICAgICAgICAtLWJhY2tncm91bmQ6IG5vbmU7XG4gICAgICAgICAgICAtLWNvbG9yOiAjRkVGRkZDO1xuICAgICAgICB9XG4gICAgICAgIHAge1xuICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXRpbnQpO1xuICAgICAgICAgICAgZm9udC1zaXplOiAuOGVtO1xuICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubmV3LXBvc3QtY29udGVudCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICAgIGRpc3BsYXk6IGdyaWQ7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBncmlkLXRlbXBsYXRlLXJvd3M6IGF1dG8gMWZyIDRmcjtcbiAgICAubmV3LXBvc3QtY2F0ZWdvcnkge1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgICAgIHBhZGRpbmc6IDQlO1xuICAgICAgICBpb24tc2VsZWN0IHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktc2hhZGUpO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMnB4O1xuICAgICAgICAgICAgcGFkZGluZzogMiU7XG4gICAgICAgICAgICB3aWR0aDogNDAlO1xuICAgICAgICB9XG4gICAgfVxuICAgIC5uZXctcG9zdC1jb250ZW50LXRleHQge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBub25lO1xuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgICAgICBwYWRkaW5nOiAwIDQlIDAgNCU7XG4gICAgfVxuXG4gICAgaW9uLWl0ZW0ge1xuICAgICAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXNoYWRlKTtcbiAgICAgICAgLS1jb2xvcjogI0ZFRkZGQztcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICB9XG5cbiAgICAuY29udGVudC10ZXh0LWxhc3Qge1xuICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgfVxufVxuXG4vL0ZvciB0eXBpY2FsIG1vYmlsZSBkZXZpY2VzXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDY3OXB4KSB7XG4gICAgLm5ldy1wb3N0LWZvcm0ge1xuICAgICAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IG5vbmU7XG4gICAgICAgIHdpZHRoOiAxMDB2dztcbiAgICB9XG5cbiAgICAubmV3LXZveC10aXRsZSB7XG4gICAgICAgIHBhZGRpbmc6IDIlIDQlIDQlIDQlO1xuICAgICAgICBpb24tYnV0dG9uIHtcbiAgICAgICAgICAgIHdpZHRoOiA4MHB4O1xuICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgICAgICAgICAgJjpsYXN0LWNoaWxkIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogMTUwcHg7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubmV3LXBvc3QtY29udGVudCB7XG4gICAgICAgIGdyaWQtdGVtcGxhdGUtcm93czogbm9uZTtcbiAgICAgICAgcm93LWdhcDogNCU7XG4gICAgICAgIC5uZXctcG9zdC1jb250ZW50LXRleHQge1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5uZXctcG9zdC1jYXRlZ29yeSB7XG4gICAgICAgIHBhZGRpbmc6IDIlICFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgLm5ldy1wb3N0LWltZyBsYWJlbHtcbiAgICAgICAgaW1nIHtcbiAgICAgICAgICAgIG1heC1oZWlnaHQ6IDM1dmg7XG4gICAgICAgIH1cbiAgICB9XG59Il19 */";
      /***/
    },

    /***/
    "wao6":
    /*!***********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/post-options/post-options.component.html ***!
      \***********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function wao6(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-item (click)=\"report()\">\n  <ion-icon slot=\"start\" name=\"flag\"></ion-icon>\n  <ion-label>Denunciar</ion-label>\n</ion-item>\n<ion-item (click)=\"hide()\">\n  <ion-icon slot=\"start\" name=\"eye-off\"></ion-icon>\n  <ion-label>Ocultar</ion-label>\n</ion-item>";
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-main-main-module-es5.js.map